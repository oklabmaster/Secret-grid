// index.html이 참조하는 style.css와 *.js를 안에 넣어 하나의 HTML로 묶습니다.
// 출력: dist/Secret_Grid.html (그대로 열어서 실행) + dist/artifact.html (게시용, 문서 껍데기 제외)
const fs=require('fs'),path=require('path');const dir=__dirname;
let html=fs.readFileSync(path.join(dir,'index.html'),'utf8');
html=html.replace(/<link rel="stylesheet" href="([^"]+\.css)">/g,(m,f)=>`<style>\n${fs.readFileSync(path.join(dir,f),'utf8')}\n</style>`);
html=html.replace(/<script src="([^":]+\.js)"><\/script>/g,(m,f)=>{if(f==='mock.js')return'';return`<script>\n${fs.readFileSync(path.join(dir,f),'utf8').replace(/<\/script/gi,'<\\/script')}\n</script>`});
if(/src="[^":]+\.js"|href="[^":]+\.css"/.test(html))throw new Error('묶이지 않은 로컬 파일 참조가 남아 있어요');
fs.mkdirSync(path.join(dir,'dist'),{recursive:true});fs.writeFileSync(path.join(dir,'dist','Secret_Grid.html'),html);
// 게시용: <head>의 title·meta·link(폰트)·style + <body> 내용만
const head=html.match(/<head>([\s\S]*?)<\/head>/)[1],body=html.match(/<body[^>]*>([\s\S]*)<\/body>/)[1];
const keep=(head.match(/<title>[\s\S]*?<\/title>/)||[''])[0]+'\n<meta name="claude:viewport-fit-sides" content="cover">\n'+(head.match(/<link[^>]+fonts\.googleapis[^>]*>/g)||[]).join('\n')+'\n'+(head.match(/<style>[\s\S]*?<\/style>/g)||[]).join('\n');
fs.writeFileSync(path.join(dir,'dist','artifact.html'),keep+'\n'+body);
console.log('built',(html.length/1024).toFixed(1)+'KB');
// 앱용: 인터넷 글꼴 연결을 빼고(오프라인, 기기 기본 글꼴 사용) 안드로이드 프로젝트 안에 넣음
const appHtml=html.replace(/<link rel="preconnect"[^>]*>\s*/g,'').replace(/<link[^>]+fonts\.googleapis[^>]*>\s*/g,'');
const appDir=path.join(dir,'android','app','src','main','assets','www');
if(fs.existsSync(path.join(dir,'android'))){fs.mkdirSync(appDir,{recursive:true});fs.writeFileSync(path.join(appDir,'index.html'),appHtml);console.log('app  ',(appHtml.length/1024).toFixed(1)+'KB → android/app/src/main/assets/www/index.html')}

