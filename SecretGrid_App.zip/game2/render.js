/* SECRET GRID 행사판 — 캔버스 그리기 (UI 디자이너)
 * 전역 SGRender. 엔진(SGEngine)의 상태 S를 읽기만 하고 절대 바꾸지 않음.
 *
 *  const R = SGRender.createRenderer(canvas)
 *  R.setTrack(tiles, opts)   tiles: S.tiles 형태[{variant,routes,locked}] 또는 변형 번호 배열[9]
 *                            opts: {locked?:bool[9], selectedTile?:number}
 *                            → 트랙 레이어를 오프스크린 캔버스에 캐시. 변형·잠금·선택이 바뀔 때만 다시 그림
 *                              (drawFrame도 매 프레임 S.tiles를 확인해 바뀌었으면 자동으로 다시 캐시함)
 *  R.drawFrame(S|null, view) view: {teamIdx(차 idx→팀 번호-1, 색·모양·번호에 사용), selectedTile, highlightIdx, colors, labels, showBadges, mode:'preview'|'race',
 *                                   count(미리보기 출발선 차 수), sectors(미리보기 구간 표시, 기본 true)}
 *  R.resize()                캔버스 표시 크기·DPR 반영 (창 크기 바뀔 때 호출. 자동 ResizeObserver도 붙어 있음)
 *  R.setQuality(1|2)         최대 DPR (프레임이 느리면 1)
 *  R.pick(clientX, clientY)  → 조각 인덱스(0~8) 또는 -1
 *  R.toLogical(clientX, clientY) → {x,y} 캔버스 논리 좌표
 *  SGRender.COLORS[10], SGRender.TEXT[10], SGRender.SHAPE[10] ('rect'|'cut'), SGRender.W/H
 */
(function(G){
'use strict';
const W=760,H=650;
// 팀 1~10 색 (Okabe–Ito 8색 + 와인·화이트). 1~5팀(A조)은 둥근 사각 번호판, 6~10팀(B조)은 모서리를 깎은 번호판
// — 색각이상에서 가까워지는 쌍(4·8, 2·8, 3·10)은 번호판 모양이 서로 다름.
const COLORS=['#D55E00','#0072B2','#F0E442','#009E73','#1F242C','#E69F00','#56B4E9','#CC79A7','#882255','#ECEDEA'];
const TEXT  =['#FFFFFF','#FFFFFF','#15181D','#FFFFFF','#FFFFFF','#15181D','#15181D','#15181D','#FFFFFF','#15181D'];
const EDGE  =['#FFFFFF','#FFFFFF','#15181D','#FFFFFF','#FFFFFF','#15181D','#15181D','#15181D','#FFFFFF','#15181D'];
const SHAPE =['rect','rect','rect','rect','rect','cut','cut','cut','cut','cut'];
// 캔버스 안 색 — 한 색은 한 뜻: 빨강=트랩·피격, 호박=지름길, 청록=방어막, 금=1위, 먹=선택·고정
const C={map:'#E4E8E3',cell:'#D9DFD9',cellLine:'#C5CDC6',edge:'#F7F8F6',road:'#3C434C',ink:'#15181D',muted:'#5E6873',
 sel:'#15181D',trap:'#E0352B',shortcut:'#E8A400',shield:'#13A3B4',gold:'#E9B10C',flash:'#FFF1C2',white:'#FFFFFF'};
const F={num:"'Barlow Condensed','Arial Narrow','IBM Plex Sans KR',sans-serif",ui:"'IBM Plex Sans KR','Noto Sans KR','Noto Sans CJK KR','Apple SD Gothic Neo','Malgun Gothic',sans-serif"};
const TILE_ORDER_9=[[0,0],[1,0],[2,0],[2,1],[1,1],[0,1],[0,2],[1,2],[2,2]];
const PI2=Math.PI*2;

// 둥근 사각형 (ctx.roundRect 없는 구형 기기 대응 — 항상 arcTo로 그림)
function rr(g,x,y,w,h,r){r=Math.min(r,w/2,h/2);g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
function cut(g,x,y,w,h,r){g.moveTo(x+r,y);g.lineTo(x+w-r,y);g.lineTo(x+w,y+r);g.lineTo(x+w,y+h-r);g.lineTo(x+w-r,y+h);g.lineTo(x+r,y+h);g.lineTo(x,y+h-r);g.lineTo(x,y+r);g.closePath()}
function plate(g,idx,x,y,w,h){if(SHAPE[idx%10]==='cut')cut(g,x,y,w,h,h*.3);else rr(g,x,y,w,h,h*.22)}
function E(){return G.SGEngine}

function createRenderer(canvas,ro){const VIEWPORT=!!(ro&&ro.viewport); // viewport: 캔버스 크기(화면 영역)에 맞춰 지도 일부를 보여주고 카메라로 스크롤
 const ctx=canvas.getContext('2d');
 // 조각 수에 따라 바뀌는 지도 크기·배치 (렌더러마다 따로)
 let W=760,H=650,VW=760,VH=650,TILE_ORDER=TILE_ORDER_9,NT=9,COLS=3,ROWS=3;
 function setLayout(N){if(!N||N===NT)return;const L=E().layoutOf(N);NT=L.N;COLS=L.cols;ROWS=L.rows;W=L.W;H=L.H;TILE_ORDER=L.order.map(o=>[o[0],o[1]]);if(!VIEWPORT){canvas.style.aspectRatio=`${W} / ${H}`;canvas.style.setProperty('--ar',(W/H).toFixed(4))}trackKey='';resize()}
 const layer=(typeof document!=='undefined')?document.createElement('canvas'):null;
 let lctx=layer&&layer.getContext('2d');
 let maxDpr=2,dpr=1,cssW=W,trackTiles=null,trackKey='',opts={},dirty=true,zoomHint=1,ls=1; // ls: 트랙 캐시 배율(확대해도 선명하게)

 function resize(){const r=canvas.getBoundingClientRect?canvas.getBoundingClientRect():{width:W};cssW=r.width||W;
  const dev=(typeof window!=='undefined'&&window.devicePixelRatio)||1;
  // 버퍼 배율 = 실제 표시 픽셀 / 760 (최대 maxDpr). 크게 띄운 프로젝터 화면도 선명하고, 작은 폰 화면은 버퍼를 줄임
  // 보이는 창의 논리 크기: 일반은 지도 전체, viewport면 지도 폭에 맞추고 높이는 화면 비율대로
  VW=W;VH=VIEWPORT&&r.height>0&&r.width>0?Math.round(W*r.height/r.width):H;
  const scale=Math.min(maxDpr,Math.max(1,cssW*dev/VW));const bw=Math.round(VW*scale),bh=Math.round(VH*scale);
  if(canvas.width!==bw||canvas.height!==bh){canvas.width=bw;canvas.height=bh}
  dpr=scale;ls=Math.min(dpr*Math.max(1,zoomHint),3000/W,3200/H);const lw=Math.round(W*ls),lh=Math.round(H*ls);if(layer&&(layer.width!==lw||layer.height!==lh)){layer.width=lw;layer.height=lh}dirty=true}
 function setZoomHint(z){const v=Math.max(1,Math.min(3,z||1));if(v!==zoomHint){zoomHint=v;resize()}}
 function setQuality(q){maxDpr=q>=2?2:1;resize()}

 function norm(tiles){if(!tiles)return null;const e=E();return tiles.map((t,i)=>typeof t==='number'?{variant:t,routes:e.tileGeom(i,t,tiles.length).routes,locked:false}:t)}
 function keyOf(tiles,sel,locked){let k=tiles.length+':'+sel+'|';for(let i=0;i<tiles.length;i++)k+=tiles[i].variant+((tiles[i].locked||(locked&&locked[i]))?'L':'')+',';return k}
 function setTrack(tiles,o){if(tiles)setLayout(tiles.length);trackTiles=norm(tiles);opts=Object.assign({},o||{});trackKey='';dirty=true}

 // ── 트랙 레이어 (캐시) ──
 function paintTrack(tiles,sel,locked,fz){const g=lctx;g.setTransform(ls,0,0,ls,0,0);g.clearRect(0,0,W,H);
  g.fillStyle=C.map;g.fillRect(0,0,W,H);g.lineJoin='round';g.lineCap='round';
  tiles.forEach((t,i)=>{const [col,row]=TILE_ORDER[i],x=65+col*210,y=65+row*180,isL=t.locked||(locked&&locked[i]);
   g.beginPath();rr(g,x+4,y+4,202,172,10);g.fillStyle=C.cell;g.fill();
   if(isL){g.setLineDash([7,5]);g.lineWidth=2;g.strokeStyle=C.muted;g.stroke();g.setLineDash([])}else{g.lineWidth=1;g.strokeStyle=C.cellLine;g.stroke()}});
  if(fz){for(let i=Math.max(0,NT-3);i<NT;i++){const [col,row]=TILE_ORDER[i],x=65+col*210,y=65+row*180;g.beginPath();rr(g,x+4,y+4,202,172,12);g.fillStyle='rgba(233,177,12,.22)';g.fill();g.lineWidth=3;g.strokeStyle=C.gold;g.setLineDash([10,7]);g.stroke();g.setLineDash([])}}
  const routes=[];tiles.forEach(t=>t.routes.forEach(r=>routes.push(r.points)));
  const path=pts=>{g.beginPath();g.moveTo(pts[0].x,pts[0].y);for(let j=1;j<pts.length;j++)g.lineTo(pts[j].x,pts[j].y)};
  for(const pts of routes){path(pts);g.strokeStyle=C.edge;g.lineWidth=38;g.stroke()}
  for(const pts of routes){path(pts);g.strokeStyle=C.road;g.lineWidth=31;g.stroke()}
  // 갈림목: 먹색 마름모 + 갈래 수
  tiles.forEach(t=>{if(t.routes.length<2)return;const p=t.routes[0].points[16];g.beginPath();g.moveTo(p.x,p.y-12);g.lineTo(p.x+12,p.y);g.lineTo(p.x,p.y+12);g.lineTo(p.x-12,p.y);g.closePath();g.fillStyle=C.white;g.fill();g.lineWidth=2;g.strokeStyle=C.ink;g.stroke();
   g.fillStyle=C.ink;g.font=`700 15px ${F.num}`;g.textAlign='center';g.textBaseline='middle';g.fillText(String(t.routes.length),p.x,p.y+1)});
  // 조각 번호(작게, 모서리) + 고정 자물쇠
  tiles.forEach((t,i)=>{const [col,row]=TILE_ORDER[i],x=65+col*210,y=65+row*180,isL=t.locked||(locked&&locked[i]);
   g.fillStyle=C.muted;g.font=`600 14px ${F.num}`;g.textAlign='left';g.textBaseline='top';g.fillText(String(i+1),x+12,y+10);
   if(isL)lock(g,x+186,y+20)});
  // 출발·결승: 체커 줄
  const e=E(),fake={tiles};[0,1].forEach(p=>{const a=e.at(fake,p===0?0:.99999,0),ang=Math.atan2(a.dy,a.dx);g.save();g.translate(a.x,a.y);g.rotate(ang);
   for(let xx=0;xx<2;xx++)for(let yy=0;yy<4;yy++){g.fillStyle=(xx+yy)%2?C.ink:C.white;g.fillRect(xx*6-6,yy*6-12,6,6)}g.restore();
   g.fillStyle=C.ink;g.font=`700 14px ${F.ui}`;g.textAlign='center';g.textBaseline='bottom';g.fillText(p?'결승':'출발',a.x+(p?-6:8),a.y-18)});
  if(fz){const fzt=TILE_ORDER.slice(Math.max(0,NT-3)),xs=fzt.map(o=>65+o[0]*210),tx=(Math.min(...xs)+Math.max(...xs)+210)/2,ty=65+Math.min(...fzt.map(o=>o[1]))*180+2;g.font=`700 15px ${F.ui}`;const tw=(g.measureText('결승 구간')||{width:72}).width||72;g.beginPath();rr(g,tx-tw/2-10,ty-13,tw+20,26,13);g.fillStyle=C.gold;g.fill();g.fillStyle=C.ink;g.textAlign='center';g.textBaseline='middle';g.fillText('결승 구간',tx,ty+1)}
  // 선택 조각: 먹색 3px 테두리
  if(sel>=0&&sel<NT){const [col,row]=TILE_ORDER[sel],x=65+col*210,y=65+row*180;g.beginPath();rr(g,x+3,y+3,204,174,11);g.lineWidth=3.5;g.strokeStyle=C.sel;g.stroke()}
  g.textAlign='left';g.textBaseline='alphabetic'}
 function lock(g,x,y){g.save();g.translate(x,y);g.fillStyle=C.muted;g.strokeStyle=C.muted;g.lineWidth=2.4;g.beginPath();g.arc(0,-4,5,Math.PI,0);g.stroke();g.beginPath();rr(g,-7,-4,14,11,2);g.fill();g.restore()}

 // ── 프레임 ──
 const pos=new Array(12),placed=[];let mem=[],memS=null; // 번호표 자리 기억(같은 자리 유지 + 부드럽게 이동)
 function badgeSize(){const k=cssW/W||1;const screenH=Math.max(22,Math.min(34,cssW*.03));return screenH/k}
 function drawFrame(S,view){view=view||{};if(!lctx){return}
  const tiles=S?S.tiles:trackTiles;if(tiles)setLayout(tiles.length);if(!tiles){ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle=C.map;ctx.fillRect(0,0,W,H);return}
  const sel=view.selectedTile===undefined?(opts.selectedTile===undefined?-1:opts.selectedTile):view.selectedTile;
  const locked=(S&&S.cfg&&S.cfg.locked)||opts.locked,fz=!!view.finalZone;const key=keyOf(tiles,sel,locked)+(fz?'F':'');
  if(dirty||key!==trackKey){paintTrack(tiles,sel,locked,fz);trackKey=key;dirty=false}
  // 카메라: view.cam={x,y,z} (논리 좌표 중심, 배율). 지도 밖이 보이지 않게 가둠
  const cam=view.cam||{},z=Math.max(1,cam.z||1),hw=VW/(2*z),hh=VH/(2*z),cx=Math.max(hw,Math.min(W-hw,cam.x===undefined?W/2:cam.x)),cy=2*hh>=H?H/2:Math.max(hh,Math.min(H-hh,cam.y===undefined?H/2:cam.y));
  const ox=dpr*(VW/2-cx*z)+(cam.sx||0)*dpr*z,oy=dpr*(VH/2-cy*z)+(cam.sy||0)*dpr*z;
  ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle=C.map;ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.setTransform(dpr*z/ls,0,0,dpr*z/ls,ox,oy);ctx.drawImage(layer,0,0);ctx.setTransform(dpr*z,0,0,dpr*z,ox,oy);
  const e=E(),t=S?S.t:0,race=view.mode!=='preview'&&!!S,TI=view.teamIdx,tix=k=>TI&&TI[k]!==undefined?TI[k]:k,cols=TI?COLORS.map((_,k)=>COLORS[tix(k)%10]):(view.colors||COLORS),TX=TI?TEXT.map((_,k)=>TEXT[tix(k)%10]):TEXT,TXc=TX;
  // 변형된 조각 번쩍임 (1초 동안 옅어짐)
  if(S)S.tiles.forEach((tl,i)=>{if(!(tl.flash>t))return;const a=Math.min(1,tl.flash-t),[col,row]=TILE_ORDER[i],x=65+col*210,y=65+row*180;ctx.globalAlpha=.55*a;ctx.beginPath();rr(ctx,x+4,y+4,202,172,10);ctx.lineWidth=6;ctx.strokeStyle=C.shortcut;ctx.stroke();ctx.globalAlpha=1});
  // 미리보기: 장치 구간(초·중·후) 위치 안내
  if(!race&&view.sectors!==false){const fake={tiles};['초반','중반','후반'].forEach((s,k)=>{const a=e.at(fake,[.25,.5,.75][k],0);tag(ctx,s,a.x,a.y-34,'rgba(21,24,29,.82)',C.white,`600 13px ${F.ui}`)})}
  drawHazards(S,tiles,view,t,race);
  if(S)drawDevices(S,t,cols);
  // 차
  let cars,n;if(S){cars=S.cars;n=cars.length}else{n=Math.min(10,view.count|0);cars=null}
  const fake=S||{tiles};
  for(let k=0;k<n;k++){const c=cars?cars[k]:{idx:k,p:0,lane:laneFor(k,n),spin:0,slow:0,route:{}};const a=cars?e.carPos(S,c):e.at(fake,0,0);
   const len=Math.sqrt(a.dx*a.dx+a.dy*a.dy)||1,nx=-a.dy/len,ny=a.dx/len,lane=(c.lane||0)*1.45;let x=a.x+nx*lane,y=a.y+ny*lane;
   if(!cars){const b=e.at(fake,.004+(n-1-k)*.0095,0),bl=Math.sqrt(b.dx*b.dx+b.dy*b.dy)||1,off=(k%2?8:-8);x=b.x-b.dy/bl*off;y=b.y+b.dx/bl*off;pos[k]={x,y,ang:Math.atan2(b.dy,b.dx)};continue}
   pos[k]={x,y,ang:Math.atan2(a.dy,a.dx)}}
  const order=S?e.standings(S):null,leader=race&&order?order[0]:null;
  // 차 크기: 화면에 작게 보일수록 캔버스 좌표에서 키워 번호가 읽히게
  const sk=cssW/W||1,fsz=Math.min(22,Math.max(14,11/sk)),chh=fsz+9,cl=Math.round(chh*1.9);
  // 1위 바닥 표시 (금색 원)
  if(leader){const P=pos[leader.idx];ctx.beginPath();ctx.arc(P.x,P.y,cl*.66,0,PI2);ctx.fillStyle='rgba(233,177,12,.28)';ctx.fill();ctx.lineWidth=2.5;ctx.strokeStyle=C.gold;ctx.stroke()}
  const drawSeq=order?order.map(c=>c.idx).reverse():Array.from({length:n},(_,k)=>k);
  for(const k of drawSeq){const c=cars?cars[k]:null,P=pos[k],idx=k;const spin=c&&race&&c.spin>t,slow=c&&race&&c.slow>t&&c.time===null;
   ctx.save();ctx.translate(P.x,P.y);ctx.rotate(P.ang+(spin?t*16:0));
   ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();rr(ctx,-cl/2+1.5,-chh/2+1.5,cl,chh,chh*.32);ctx.fill();
   ctx.beginPath();rr(ctx,-cl/2,-chh/2,cl,chh,chh*.32);ctx.fillStyle=cols[idx%10];ctx.fill();ctx.lineWidth=2.2;ctx.strokeStyle=slow||spin?C.trap:(tix(idx)%10===9||tix(idx)%10===2?C.ink:C.white);ctx.stroke();
   {const hw=Math.max(3.5,chh*.17),hh=Math.max(5,chh*.27),hx=cl/2-hw-1.6;ctx.fillStyle='#FFF6CF';ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=1;for(const hy of[-chh/2+2.4,chh/2-2.4-hh]){ctx.beginPath();rr(ctx,hx,hy,hw,hh,hw*.4);ctx.fill();ctx.stroke()}}ctx.restore()}
  // 번호: 차 한가운데, 글자는 늘 똑바로
  for(const k of drawSeq){const c=cars?cars[k]:null,P=pos[k],num=String(tix(k)+1);
   ctx.font=`700 ${Math.round(fsz)}px ${F.num}`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=TXc[k%10];ctx.fillText(num,P.x,P.y+fsz*.05);
   if(leader&&leader.idx===k)crown(ctx,P.x,P.y-chh*.5-5,fsz*.5);
   if(race&&S&&S.cfg&&S.cfg.battle&&c&&c.time===null&&c.gauge>=1){ctx.beginPath();ctx.arc(P.x+cl*.42,P.y-chh*.55,fsz*.22,0,PI2);ctx.fillStyle=C.trap;ctx.fill();ctx.lineWidth=1.5;ctx.strokeStyle=C.white;ctx.stroke()}}
  ctx.textAlign='left';ctx.textBaseline='alphabetic';
  // 방어막이 막은 순간
  if(S&&S.events)for(let j=S.events.length-1;j>=0;j--){const ev=S.events[j];if(t-ev.t>.9)break;if(ev.k!=='block')continue;const P=pos[ev.a];if(!P)continue;const f=(t-ev.t)/.9;
   ctx.globalAlpha=1-f;hex(ctx,P.x,P.y,18+f*12);ctx.lineWidth=4;ctx.strokeStyle=C.shield;ctx.stroke();if(f<.6)tag(ctx,'방어!',P.x,P.y-38,C.shield,C.white,`700 14px ${F.ui}`);ctx.globalAlpha=1}
  if(view.highlightIdx>=0&&pos[view.highlightIdx]&&view.highlightIdx<n){const P=pos[view.highlightIdx],r=22+3*Math.abs(((t*2)%2)-1);ctx.beginPath();ctx.arc(P.x,P.y,r,0,PI2);ctx.lineWidth=3;ctx.strokeStyle=C.ink;ctx.stroke()}
  if(S)drawShots(S,t,cols);}

 function laneFor(i,n){return n<=8?(i-(n-1)/2)*1.9:((i%7)-3)*2.4}

 // 맵 트랩: 노란 경고 삼각형. 갈래길이면 모든 갈래에 표시. 미리보기에선 걸릴 확률도 함께
 function drawHazards(S,tiles,view,t,race){const e=E(),list=S?S.hazards:(view.hazards||[]).map(p=>({p}));if(!list||!list.length)return;const fake=S||{tiles},N=tiles.length;
  const recent=new Set();if(S&&S.events)for(let j=S.events.length-1;j>=0;j--){const ev=S.events[j];if(t-ev.t>.5)break;if(ev.k==='hazard')recent.add(ev.h)}
  list.forEach((z,h)=>{const i=e.tileIndex(z.p,N),nr=tiles[i].routes.length;for(let r=0;r<nr;r++){const a=e.at(fake,z.p,r);
   if(recent.has(h)){ctx.beginPath();ctx.arc(a.x,a.y,22,0,PI2);ctx.lineWidth=4;ctx.strokeStyle=C.trap;ctx.stroke()}
   const s2=13;ctx.beginPath();ctx.moveTo(a.x,a.y-s2);ctx.lineTo(a.x+s2*1.05,a.y+s2*.75);ctx.lineTo(a.x-s2*1.05,a.y+s2*.75);ctx.closePath();ctx.fillStyle='#FFD21A';ctx.fill();ctx.lineWidth=2.5;ctx.lineJoin='round';ctx.strokeStyle=C.ink;ctx.stroke();
   ctx.fillStyle=C.ink;ctx.font=`800 14px ${F.num}`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('!',a.x,a.y+2);
   if(!race&&r===0&&e.HAZARD){const ch=e.HAZARD.chance[e.hazardSector(z.p)];tag(ctx,Math.round(ch*100)+'%',a.x,a.y+26,'rgba(21,24,29,.85)',C.white,`700 12px ${F.num}`)}}});
  ctx.textAlign='left';ctx.textBaseline='alphabetic'}
 function drawDevices(S,t,cols){const e=E();for(const d of S.devices){if(!d.used||d.type==='shield')continue;const a=e.at(S,d.p,d.route||0);
   if(d.type==='shortcut'&&!d.fail&&d.skip){const b=e.at(S,Math.min(.99999,d.p+d.skip),d.endRoute||0);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.quadraticCurveTo((a.x+b.x)/2,(a.y+b.y)/2-30,b.x,b.y);ctx.setLineDash([6,6]);ctx.lineWidth=3;ctx.strokeStyle=C.shortcut;ctx.stroke();ctx.setLineDash([])}
   ctx.save();ctx.translate(a.x,a.y);ctx.beginPath();ctx.arc(0,0,13,0,PI2);
   ctx.fillStyle=d.type==='trap'?C.trap:d.fail?C.ink:C.shortcut;ctx.fill();ctx.lineWidth=3;ctx.strokeStyle=cols[d.owner%10];ctx.stroke();ctx.lineWidth=1;ctx.strokeStyle=C.white;ctx.beginPath();ctx.arc(0,0,15,0,PI2);ctx.stroke();
   ctx.strokeStyle=d.type==='shortcut'&&!d.fail?C.ink:C.white;ctx.lineWidth=3;ctx.lineCap='round';ctx.beginPath();
   if(d.type==='trap'){ctx.moveTo(-5,-5);ctx.lineTo(5,5);ctx.moveTo(5,-5);ctx.lineTo(-5,5)}
   else if(d.fail){ctx.arc(0,0,6,0,PI2);ctx.moveTo(-4,4);ctx.lineTo(4,-4)}
   else{ctx.moveTo(-5,5);ctx.lineTo(5,-5);ctx.moveTo(-1,-5);ctx.lineTo(5,-5);ctx.lineTo(5,1)}
   ctx.stroke();ctx.restore()}}

 const SPOTS=[[0,-1],[0,1],[-1.1,-.7],[1.1,-.7],[-1.1,.7],[1.1,.7],[0,-2],[0,2],[-2.1,0],[2.1,0],[-1.2,-1.8],[1.2,-1.8],[-1.2,1.8],[1.2,1.8],[0,-3],[-2.3,-1.2],[2.3,-1.2],[-2.3,1.2],[2.3,1.2],[0,3],[-3.2,0],[3.2,0]];
 function drawBadges(S,n,order,leader,cols,view,race,t){const TI=view.teamIdx,tix=k=>TI&&TI[k]!==undefined?TI[k]:k,TX=TI?TEXT.map((_,k)=>TEXT[tix(k)%10]):TEXT;const bh=badgeSize(),bw=bh*1.18,gap=bh*.08;placed.length=0;
  for(let k=0;k<n;k++){const P=pos[k];placed.push(P.x-14,P.y-10,28,20)}
  const hit=(x,y,w,h)=>{for(let j=0;j<placed.length;j+=4){const qx=placed[j],qy=placed[j+1],qw=placed[j+2],qh=placed[j+3];if(x<qx+qw+gap&&qx<x+w+gap&&y<qy+qh+gap&&qy<y+h+gap)return true}return false};
  const fs=Math.round(bh*.78),labels=view.labels;
  // 번호표는 순위와 상관없이 팀 순서로 자리를 잡고, 쓰던 자리가 비어 있으면 그대로 유지(덜 움직이게)
  if(memS!==S){mem=[];memS=S}
  const byIdx=order.slice().sort((a,b)=>a.idx-b.idx);
  for(const c of byIdx){const k=c.idx,P=pos[k];if(!P)continue;const isLead=leader&&leader.idx===k,s=1,w=bw*(tix(k)>=9?1.25:1),h=bh;
   const spotXY=i=>{const [ux,uy]=SPOTS[i];return[P.x+ux*(w*.5+bh*.55)-w/2,P.y+uy*(h*.5+bh*.45)-h/2]};
   const ok=i=>{const [x,y]=spotXY(i);return!(x<2||y<2||x+w>W-2||y+h>H-2)&&!hit(x,y,w,h)};
   const m=mem[k]||(mem[k]={spot:-1,dx:null,dy:null,hold:0});let spot=-1;
   if(m.spot>=0&&ok(m.spot))spot=m.spot;else{for(let i=0;i<SPOTS.length;i++)if(ok(i)){spot=i;break}}
   // 더 좋은(차에 가까운) 자리가 생겨도 0.6초 동안은 기다렸다가 옮김
   if(spot===m.spot&&spot>0){let best=-1;for(let i=0;i<spot;i++)if(ok(i)){best=i;break}if(best>=0){m.hold+=1/60;if(m.hold>.6){spot=best;m.hold=0}}else m.hold=0}else m.hold=0;
   let tx,ty;if(spot>=0){[tx,ty]=spotXY(spot)}else{tx=Math.max(2,Math.min(W-w-2,P.x-w/2));ty=Math.max(2,P.y-h-bh*.6)}
   m.spot=spot;placed.push(tx,ty,w,h);
   const ox=tx-P.x,oy=ty-P.y;if(m.dx===null){m.dx=ox;m.dy=oy}else{m.dx+=(ox-m.dx)*.22;m.dy+=(oy-m.dy)*.22}
   const bx=P.x+m.dx,by=P.y+m.dy;const cx=bx+w/2,cy=by+h/2;
   const dx=cx-P.x,dy=cy-P.y;if(dx*dx+dy*dy>(bh*1.1)*(bh*1.1)){ctx.beginPath();ctx.moveTo(P.x,P.y);ctx.lineTo(cx,cy);ctx.lineWidth=3.2;ctx.strokeStyle=C.white;ctx.stroke();ctx.lineWidth=1.4;ctx.strokeStyle=C.ink;ctx.stroke()}
   ctx.beginPath();plate(ctx,tix(k),bx,by,w,h);ctx.fillStyle=cols[k%10];ctx.fill();
   ctx.lineWidth=isLead?3.2:1.8;ctx.strokeStyle=isLead?C.gold:(k%10===9||k%10===2?C.ink:C.white);ctx.stroke();
   if(isLead){ctx.beginPath();plate(ctx,tix(k),bx-2.6,by-2.6,w+5.2,h+5.2);ctx.lineWidth=1.4;ctx.strokeStyle=C.ink;ctx.stroke();crown(ctx,cx,by-3,h*.42)}
   if(race&&S&&S.cfg&&S.cfg.battle&&c.time===null&&c.gauge>=1){ctx.beginPath();ctx.arc(bx+w,by,h*.2,0,PI2);ctx.fillStyle=C.trap;ctx.fill();ctx.lineWidth=1.5;ctx.strokeStyle=C.white;ctx.stroke()}
   ctx.fillStyle=TX[k%10];ctx.font=`700 ${Math.round(fs*s)}px ${F.num}`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(tix(k)+1),cx,cy+h*.04);
   if(labels&&labels[k]&&!race){ctx.font=`600 ${Math.round(bh*.5)}px ${F.ui}`;ctx.fillStyle=C.ink;ctx.textAlign='left';ctx.fillText(labels[k],bx+w+4,cy)}}
  ctx.textAlign='left';ctx.textBaseline='alphabetic'}
 function crown(g,x,y,s){g.beginPath();g.moveTo(x-s,y);g.lineTo(x-s,y-s*.9);g.lineTo(x-s*.5,y-s*.45);g.lineTo(x,y-s*1.1);g.lineTo(x+s*.5,y-s*.45);g.lineTo(x+s,y-s*.9);g.lineTo(x+s,y);g.closePath();g.fillStyle=C.gold;g.fill();g.lineWidth=1.4;g.strokeStyle=C.ink;g.stroke()}

 function drawShots(S,t,cols){const fl=(E().ATTACK&&E().ATTACK.flight)||.3;
  for(const s of S.shots){const age=t-s.t,A=pos[s.a],B=pos[s.b];if(!A||!B||age<0||age>fl+.6)continue;
   if(age<fl){const f=age/fl,mx=(A.x+B.x)/2,my=(A.y+B.y)/2-28,x=(1-f)*(1-f)*A.x+2*(1-f)*f*mx+f*f*B.x,y=(1-f)*(1-f)*A.y+2*(1-f)*f*my+f*f*B.y;
    ctx.beginPath();ctx.moveTo(A.x,A.y);ctx.quadraticCurveTo(mx,my,B.x,B.y);ctx.setLineDash([3,5]);ctx.lineWidth=2;ctx.strokeStyle='rgba(224,53,43,.6)';ctx.stroke();ctx.setLineDash([]);
    ctx.beginPath();ctx.arc(x,y,6,0,PI2);ctx.fillStyle=C.trap;ctx.fill();ctx.lineWidth=2;ctx.strokeStyle=C.white;ctx.stroke()}
   else{const f=(age-fl)/.6;ctx.globalAlpha=1-f;ctx.beginPath();ctx.arc(B.x,B.y,12+f*24,0,PI2);ctx.lineWidth=5*(1-f)+1;ctx.strokeStyle=s.miss?C.ink:C.trap;ctx.stroke();
    if(f<.6)tag(ctx,s.miss?'회피':'명중',B.x,B.y-40,s.miss?C.ink:C.trap,C.white,`700 15px ${F.ui}`);ctx.globalAlpha=1}}
  for(const b of S.bolts||[]){const age=t-b.t,B=pos[b.b];if(!B||age<0||age>.9)continue;ctx.save();ctx.globalAlpha=age<.6?1:1-(age-.6)/.3;const top=Math.min(120,B.y-6);
   ctx.beginPath();ctx.moveTo(B.x+4,B.y-top);[[12,.72],[-8,.5],[10,.3],[-4,.13]].forEach(([dx,f])=>ctx.lineTo(B.x+dx,B.y-top*f));ctx.lineTo(B.x,B.y);
   ctx.lineJoin='miter';ctx.lineWidth=8;ctx.strokeStyle=C.ink;ctx.stroke();ctx.lineWidth=3.5;ctx.strokeStyle='#FFF4B0';ctx.stroke();ctx.restore();
   if(age<.7)tag(ctx,'번개',B.x+30,Math.max(16,B.y-top*.6),C.ink,'#FFF4B0',`700 15px ${F.ui}`)}}

 function hex(g,x,y,r){g.beginPath();for(let k=0;k<6;k++){const a=Math.PI/6+k*Math.PI/3;const px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;k?g.lineTo(px,py):g.moveTo(px,py)}g.closePath()}
 function tag(g,text,x,y,bg,fg,font){g.font=font;const m=g.measureText(text),w=(m&&m.width)||text.length*8,h=22;g.beginPath();rr(g,x-w/2-8,y-h/2,w+16,h,5);g.fillStyle=bg;g.fill();g.fillStyle=fg;g.textAlign='center';g.textBaseline='middle';g.fillText(text,x,y+1);g.textAlign='left';g.textBaseline='alphabetic'}

 function toLogical(cx,cy){const r=canvas.getBoundingClientRect();return{x:(cx-r.left)*W/r.width,y:(cy-r.top)*H/r.height}}
 function pick(cx,cy){const p=toLogical(cx,cy);const col=Math.floor((p.x-65)/210),row=Math.floor((p.y-65)/180);if(col<0||col>=COLS||row<0||row>=ROWS)return -1;for(let i=0;i<NT;i++)if(TILE_ORDER[i][0]===col&&TILE_ORDER[i][1]===row)return i;return -1}

 resize();
 if(typeof ResizeObserver!=='undefined'){try{new ResizeObserver(()=>resize()).observe(canvas)}catch(e){}}
 if(typeof document!=='undefined'&&document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{dirty=true});
 return{setTrack,drawFrame,resize,setQuality,setZoomHint,pick,toLogical,get dpr(){return dpr},get W(){return W},get H(){return H},get VH(){return VH}}}

// 팀 번호판(HTML)용 도우미: 번호 칩 요소에 색·모양을 입힘. el은 .plate 요소, idx는 0부터
function paintPlate(el,idx){el.style.setProperty('--plate-bg',COLORS[idx%10]);el.style.setProperty('--plate-fg',TEXT[idx%10]);el.dataset.shape=SHAPE[idx%10];el.textContent=String(idx+1);return el}

G.SGRender={createRenderer,COLORS,TEXT,EDGE,SHAPE,W,H,paintPlate,canvasColors:C};
})(typeof globalThis!=='undefined'?globalThis:this);
