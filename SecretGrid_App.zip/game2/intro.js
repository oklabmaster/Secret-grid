/* SECRET GRID 인트로 — 4초
   0.0~1.0 조각 9개 조립 → 1.0~1.9 손전등 + 트랩 숨김 → 2.0~3.1 차 한 바퀴(로고 점등) → 3.1 로고 쾅 → 4.0 종료
   사용: SGIntro.play({ onDone: function(){ ...시작 화면 표시... } })   /   건너뛰기: 화면 탭 */
(function(){
  var NS='http://www.w3.org/2000/svg', root=document.getElementById('sg-intro');
  var RING='M94,166 L94,120 Q94,80 134,80 L226,80 Q266,80 266,120 L266,212 Q266,252 226,252 L134,252 Q94,252 94,212 Z';
  var TEXT='SECRET GRID', TRAP_TILE=5, ORDER=[4,0,8,2,6,1,7,3,5];
  var tilesG=root.querySelector('#sg-tiles'), car=root.querySelector('#sg-car'), word=root.querySelector('#sg-word');
  var raf=0, timer=0, cb=null, trapBg=null, letters=[];
  function el(n,a){var e=document.createElementNS(NS,n);for(var k in a)e.setAttribute(k,a[k]);return e}

  for(var i=0;i<9;i++){
    var r=Math.floor(i/3), c=i%3, x=54+c*86, y=40+r*86;
    var g=el('g',{'class':'sg-tile'});
    g.style.setProperty('--i',ORDER.indexOf(i));
    g.style.setProperty('--dx',(c-1)*240+'px');
    g.style.setProperty('--dy',(r-1)*240+'px');
    g.style.setProperty('--rot',(i===4?180:(c-1||1)*(r-1||1)*70)+'deg');
    var bg=el('rect',{'class':'sg-bg',x:x,y:y,width:80,height:80,rx:9});
    g.appendChild(bg); if(i===TRAP_TILE)trapBg=bg;
    if(i!==4){
      var cp=el('clipPath',{id:'sgc'+i}); cp.appendChild(el('rect',{x:x,y:y,width:80,height:80,rx:9})); g.appendChild(cp);
      var rg=el('g',{'clip-path':'url(#sgc'+i+')'});
      rg.appendChild(el('path',{'class':'sg-road',d:RING})); rg.appendChild(el('path',{'class':'sg-dash',d:RING}));
      g.appendChild(rg);
    }else{
      g.appendChild(el('rect',{x:x+28,y:y+28,width:24,height:24,rx:5,fill:'none',stroke:'#2A3C4D','stroke-width':2}));
    }
    tilesG.appendChild(g);
  }
  var ring=el('path',{d:RING,fill:'none'}); tilesG.appendChild(ring);
  var L=ring.getTotalLength();
  TEXT.split('').forEach(function(ch){var s=document.createElement('span');s.textContent=ch;word.appendChild(s);letters.push(s)});

  function light(n){for(var i=0;i<letters.length;i++)letters[i].classList.toggle('on',i<n)}
  function stop(){cancelAnimationFrame(raf);clearTimeout(timer)}
  function finish(){
    stop(); root.hidden=true; root.className='';
    var f=cb; cb=null; if(f)f();
    document.dispatchEvent(new Event('sgintro:done'));
  }
  function skip(){ if(root.hidden)return; stop(); root.classList.add('sg-out'); timer=setTimeout(finish,200) }
  root.addEventListener('pointerdown',skip);

  function play(opt){
    stop(); cb=opt&&opt.onDone||null;
    root.hidden=false; root.className=''; light(0); car.style.opacity=0; trapBg.classList.remove('sg-hit');
    if(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches){
      root.classList.add('sg-reduce','sg-stamp'); light(99); timer=setTimeout(skip,1200); return;
    }
    void root.offsetWidth; root.classList.add('sg-play');
    var t0=performance.now();
    (function frame(now){
      var t=(now-t0)/1000, p=(t-2.0)/1.1;
      if(p>0){
        var e=p>=1?1:(1-Math.cos(Math.PI*p))/2, len=L*e;
        var a=ring.getPointAtLength((len-1+L)%L), b=ring.getPointAtLength((len+1)%L), m=ring.getPointAtLength(len%L);
        car.setAttribute('transform','translate('+m.x+' '+m.y+') rotate('+Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI+')');
        car.style.opacity=t<3.1?1:0;
        light(Math.floor(e*letters.length+.001));
        trapBg.classList.toggle('sg-hit',e>.45&&e<.6);
      }
      if(t>=3.1){root.classList.add('sg-stamp');light(99)}
      if(t>=3.72)root.classList.add('sg-out');
      if(t>=4.0)return finish();
      raf=requestAnimationFrame(frame);
    })(t0);
  }
  window.SGIntro={play:play,skip:skip};
})();
