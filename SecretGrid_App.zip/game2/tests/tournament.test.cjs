const T=require('../tournament.js'),assert=require('assert');
// 10팀: A/B조 번갈아 3판씩 → 각 조 상위 4팀 결승 2판
let t=T.create({teams:['1팀','2팀','3팀','4팀','5팀','6팀','7팀','8팀','9팀','10팀']});
assert.equal(t.groups.length,2);assert.deepEqual(t.groups.map(g=>g.length),[5,5]);assert.equal(t.schedule.length,6);
assert.equal(T.label(t,T.current(t)),'예선 A조 1/3판');
const rnd=s=>{let a=s;return()=>(a=(a*48271)%2147483647)/2147483647};const R=rnd(7);
while(t.stage==='heat'){const race=T.current(t);const order=race.teams.slice().sort(()=>R()-.5);T.record(t,order,{[order[0]]:{landed:2,trapHits:1}})}
assert.equal(t.stage,'final');assert.equal(t.finalists.length,8);assert.equal(t.schedule.length,8);
const a4=T.standings(t,'heat',0).slice(0,4).map(r=>r.id);assert(a4.every(id=>t.finalists.includes(id)));
assert.equal(T.label(t,T.current(t)),'결승 1/2판');
while(t.stage!=='done'){const race=T.current(t);T.record(t,race.teams.slice().sort(()=>R()-.5),{})}
const fr=T.finalRanking(t);assert.equal(fr.length,10);assert(t.finalists.includes(fr[0].id));assert(!t.finalists.includes(fr[9].id));
assert(T.awards(t).length>=1);
// 동점 처리: 합계 같으면 1위 횟수 → 마지막 판 순위
let u=T.create({teams:['가','나','다'],heats:2,finals:0});
T.record(u,['t1','t2','t3']);T.record(u,['t2','t1','t3']);
const s=T.standings(u,'heat');assert.equal(s[0].total,s[1].total);assert.equal(s[0].id,'t2','마지막 판 순위가 앞선 팀');assert.equal(u.stage,'done');
// 5대 점수 10/7/5/3/1, 8대 결승 12/9/7/5/4/3/2/1
assert.deepEqual(T.pointsTable(5,false),[10,7,5,3,1]);assert.deepEqual(T.pointsTable(8,true),[12,9,7,5,4,3,2,1]);
// 저장/복구 (JSON 왕복)
const back=JSON.parse(JSON.stringify(t));assert.deepEqual(T.finalRanking(back),fr);
// 6팀: 한 조, 상위 4팀 결승
let w=T.create({teams:['a','b','c','d','e','f']});while(w.stage!=='done'){const r=T.current(w);T.record(w,r.teams.slice().reverse())}
assert.equal(w.finalists.length,4);
let z=T.create({teams:['a','b','c','d']});while(z.stage!=='done'){const r=T.current(z);T.record(z,r.teams.slice())}assert.equal(z.finalists,null,'4팀 이하는 결승 없음');
let cu=T.create({teams:['a','b','c','d','e','f'],pointsHeat:[5,3,1],finalPer:3});T.record(cu,['t1','t2','t3','t4','t5','t6']);assert.deepEqual(cu.results[0].points,{t1:5,t2:3,t3:1,t4:0,t5:0,t6:0});while(cu.stage==='heat'){const r=T.current(cu);T.record(cu,r.teams.slice())}assert.equal(cu.finalists.length,3,'사용자 지정 결승 인원');
console.log('PASS tournament: 10팀 조별 예선·결승, 동점 처리, 점수표, 저장 복구, 6팀 단일 조');
