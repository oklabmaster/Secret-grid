/* SECRET GRID 균형 시뮬레이터 (재현 가능: 시드 고정)
 * 사용: node tests/balance.cjs [--quick] [--n=5,8] [--games=N] [--workers=K] [--json]
 *  - 각 참가자가 7개 선택지(트랩 초/중/후, 지름길 초/중/후, 방어막) 중 하나를 고름(시드 RNG로 균등 배정)
 *  - 선택지별 승률과 95% 신뢰구간(Wilson) 출력
 *  - 판정: 5명 공격 ON·OFF에서 모든 선택지 승률이 공평값(1/n) ±3%p 이내가 아니면 exit code 1
 *    (3·8·10명은 참고용 ±4%p 경고만, 판정에 포함하지 않음)
 */
'use strict';
const path=require('path');
const {Worker,isMainThread,parentPort,workerData}=require('worker_threads');
const ENGINE=path.join(__dirname,'..','engine.js');
const OPTS=[{type:'trap',sector:0},{type:'trap',sector:1},{type:'trap',sector:2},{type:'shortcut',sector:0},{type:'shortcut',sector:1},{type:'shortcut',sector:2},{type:'shield',sector:0}];
const LAB=['트랩 초반','트랩 중반','트랩 후반','지름길 초반','지름길 중반','지름길 후반','방어막'];

// 판 k의 설계도: 시드 = (기본시드, 인원, 공격, k)에서 결정
function plan(E,n,battle,k,base){const seed=((base*2654435761)^(n*40503)^(battle?0x9e37:0)^Math.imul(k+1,2246822519))>>>0;const R=E.rng(seed);
 const pick=[];for(let i=0;i<n;i++)pick.push(Math.floor(R()*OPTS.length));
 return{pick,cfg:{seed:seed|0,tiles:E.randomTiles(seed^0x5bd1e995),chaos:true,battle,racers:pick.map((o,i)=>({id:'r'+i,name:'R'+i,device:OPTS[o]}))}}}
function runChunk(E,n,battle,from,to,base,over){if(over)applyOverrides(E,over);const win=new Array(OPTS.length).fill(0),cnt=new Array(OPTS.length).fill(0);let sumT=0;
 for(let k=from;k<to;k++){const {pick,cfg}=plan(E,n,battle,k,base);const S=E.createRace(cfg);E.advanceTo(S,1e9);const w=E.standings(S)[0].idx;sumT+=S.t;
  for(let i=0;i<n;i++){cnt[pick[i]]++;if(i===w)win[pick[i]]++}}
 return{win,cnt,sumT,games:to-from}}
function applyOverrides(E,o){for(const g of Object.keys(o))Object.assign(E[g],o[g])}

if(!isMainThread){const E=require(ENGINE);const d=workerData;parentPort.postMessage(runChunk(E,d.n,d.battle,d.from,d.to,d.base,d.over));return}

function wilson(w,c){if(!c)return[0,0];const z=1.96,p=w/c,den=1+z*z/c,mid=(p+z*z/(2*c))/den,h=z*Math.sqrt(p*(1-p)/c+z*z/(4*c*c))/den;return[mid-h,mid+h]}
async function runSet(n,battle,games,workers,base,over){const per=Math.ceil(games/workers),jobs=[];
 for(let w=0;w<workers;w++){const from=w*per,to=Math.min(games,from+per);if(from>=to)break;
  jobs.push(new Promise((res,rej)=>{const wk=new Worker(__filename,{workerData:{n,battle,from,to,base,over}});wk.once('message',res);wk.once('error',rej)}))}
 const parts=await Promise.all(jobs),win=new Array(OPTS.length).fill(0),cnt=new Array(OPTS.length).fill(0);let sumT=0;
 for(const p of parts){for(let i=0;i<OPTS.length;i++){win[i]+=p.win[i];cnt[i]+=p.cnt[i]}sumT+=p.sumT}
 return{n,battle,games,win,cnt,avgT:sumT/games,rows:OPTS.map((o,i)=>{const r=cnt[i]?win[i]/cnt[i]:0,[lo,hi]=wilson(win[i],cnt[i]);return{label:LAB[i],picks:cnt[i],rate:r,lo,hi}})}}
function show(res,tol){const fair=1/res.n;let bad=0;
 console.log(`\n■ ${res.n}명 · 공격 ${res.battle?'ON':'OFF'} · ${res.games}판 · 평균 ${res.avgT.toFixed(1)}초 · 공평값 ${(100*fair).toFixed(1)}% (허용 ±${(100*tol).toFixed(0)}%p)`);
 for(const r of res.rows){const dev=r.rate-fair,ok=Math.abs(dev)<=tol;if(!ok)bad++;
  console.log(`  ${(r.label+'      ').slice(0,7)} ${String(r.picks).padStart(6)}회  ${(100*r.rate).toFixed(1).padStart(5)}%  [${(100*r.lo).toFixed(1)}~${(100*r.hi).toFixed(1)}]  ${(dev>=0?'+':'')+(100*dev).toFixed(1)}%p ${ok?'':' ← 기준 밖'}`)}
 const spread=Math.max(...res.rows.map(r=>r.rate))-Math.min(...res.rows.map(r=>r.rate));console.log(`  최대-최소 차이 ${(100*spread).toFixed(1)}%p`);return bad}

async function main(){const args=process.argv.slice(2),get=(k,d)=>{const a=args.find(x=>x.startsWith('--'+k+'='));return a?a.split('=')[1]:d};
 const quick=args.includes('--quick'),json=args.includes('--json');
 const ns=get('n',quick?'5':'3,5,8,10').split(',').map(Number);
 const workers=+get('workers',Math.max(1,Math.min(8,require('os').cpus().length)));
 const base=+get('seed',20261029);const over=get('over',null)?JSON.parse(get('over')):null;
 // 판수: 선택지당 표본 = 판수*n/7. 5명 기준 기본 7000판 → 선택지당 약 5000회 (95% CI 약 ±1.1%p)
 const gamesFor=n=>+get('games',0)||Math.ceil((quick?1500:5000)*OPTS.length/n);
 const t0=Date.now();let fail=0;const out=[];
 for(const n of ns)for(const battle of [true,false]){const res=await runSet(n,battle,gamesFor(n),workers,base,over);out.push(res);
  const gate=n===5,bad=show(res,gate?.03:.04);if(gate&&bad)fail+=bad;if(!gate&&bad)console.log('  (참고용 인원 — 판정 제외)')}
 console.log(`\n시간 ${((Date.now()-t0)/1000).toFixed(1)}초, 작업자 ${workers}개${quick?' (빠른 모드: 표본 적음, 신뢰구간 넓음)':''}`);
 if(json)console.log(JSON.stringify(out.map(r=>({n:r.n,battle:r.battle,games:r.games,rows:r.rows}))));
 if(ns.includes(5)){console.log(fail?`FAIL 5명 기준 ±3%p 밖 ${fail}건`:'PASS 5명 공격 ON·OFF 모두 공평값 ±3%p 이내');process.exit(fail?1:0)}}
module.exports={runSet,OPTS,LAB};
if(require.main===module)main().catch(e=>{console.error(e);process.exit(2)});
