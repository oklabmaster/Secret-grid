const E=require('../engine.js'),assert=require('assert');
// 테스트용 결정적 난수 (청크 크기 무작위화도 재현 가능하게)
const TR=E.rng(424242);
// dsin accuracy
for(let x=-20;x<20;x+=.137)assert(Math.abs(E.dsin(x)-Math.sin(x))<1e-6,'dsin '+x);
// geometry: every variant connects, forks share entry/exit
for(let v=0;v<E.VARIANTS;v++){for(let i=0;i<9;i++){const g=E.tileGeom(i,v);assert.equal(g.routes.length,v===E.FORK3?3:v===E.FORK2?2:1);for(const r of g.routes){const s=r.points[0],e=r.points[200],s0=g.routes[0].points[0],e0=g.routes[0].points[200];assert(Math.abs(s.x-s0.x)+Math.abs(s.y-s0.y)<1e-9&&Math.abs(e.x-e0.x)+Math.abs(e.y-e0.y)<1e-9)}}
 for(let i=0;i<8;i++){const a=E.tileGeom(i,v).routes[0].points[200],b=E.tileGeom(i+1,v).routes[0].points[0];assert(Math.abs(a.x-b.x)+Math.abs(a.y-b.y)<1e-9,'connect')}}
// 트랙이 계약서 좌표계(760×650, y 65~605) 안
for(let v=0;v<E.VARIANTS;v++)for(let i=0;i<9;i++)for(const r of E.tileGeom(i,v).routes)for(const p of r.points)assert(p.x>=65-1e-9&&p.x<=695+1e-9&&p.y>=65-1e-9&&p.y<=605+1e-9,'bounds');
const DEV=[{type:'trap',sector:0},{type:'shortcut',sector:1},null,{type:'shield',sector:0},{type:'trap',sector:2},{type:'shortcut',sector:0},{type:'trap',sector:1}];
function cfg(seed,n,opt){opt=opt||{};const tiles=E.randomTiles(seed*7+1);const racers=[];for(let i=0;i<n;i++)racers.push({id:'p'+i,name:'R'+i,device:opt.dev?opt.dev(i):DEV[i%DEV.length]});return{seed,tiles,locked:opt.locked,chaos:opt.chaos!==false,battle:opt.battle!==false,racers}}
function chunked(c){const B=E.createRace(JSON.parse(JSON.stringify(c)));let t=0;while(!B.done){t+=TR()*.4;E.advanceTo(B,t,50)}return B}
let tot={hits:0,forks:0,remix:0,trap:0,short:0,block:0},maxT=0;
for(const n of [2,5,8,9,10,25,50])for(let s=1;s<=6;s++){
 const c=cfg(s*1009+n,n);assert(c.tiles.filter(v=>v>=E.FORK2).length>=2);
 const A=E.createRace(c);E.advanceTo(A,1e9);assert(A.done);assert.equal(A.finished.length,n,'all finish n='+n);
 // same plan, different frame chunking (e.g., slow laptop / late joiner) -> identical
 const B=chunked(c);
 assert.deepStrictEqual(E.summary(A),E.summary(B),'deterministic');assert.equal(JSON.stringify(A.events),JSON.stringify(B.events));assert.equal(JSON.stringify(A.recap),JSON.stringify(B.recap),'recap deterministic');
 maxT=Math.max(maxT,A.t);for(const e of A.events){if(e.k==='hit')tot.hits++;if(e.k==='remix')tot.remix++;if(e.k==='trap')tot.trap++;if(e.k==='shortcut')tot.short++;if(e.k==='block')tot.block++}
 tot.forks+=A.cars.reduce((k,car)=>k+Object.values(car.route).filter(r=>r>0).length,0);
}
assert(tot.hits>0&&tot.forks>0&&tot.remix>0&&tot.trap>0&&tot.short>0&&tot.block>0,JSON.stringify(tot));

// ── 버그 A: 지름길 점프로 뛰어넘은 구간 (점프 지점, 착지 지점]의 트랩은 발동하지 않음
{let jumps=0,before=0;
 for(let s=1;s<=300;s++)for(const off of [.01,.04,-1e-7]){
  const c={seed:s,tiles:E.randomTiles(s),chaos:false,battle:false,racers:[{id:'S',device:{type:'shortcut',sector:0}},{id:'T',device:{type:'trap',sector:0}}]};
  for(const rev of [false,true]){const S=E.createRace(c);const sd=S.devices.find(d=>d.type==='shortcut'),td=S.devices.find(d=>d.type==='trap');td.p=sd.p+off;if(rev)S.devices.reverse();
   const car=S.cars[0];let hit=false;
   while(!S.done){const old=car.p,ne=S.events.length,tdWas=td.used;E.step(S);
    if(sd.used&&old<sd.p&&!sd.fail&&!tdWas){// 점프한 스텝
     const trapNow=S.events.slice(ne).some(e=>(e.k==='trap'||e.k==='block')&&e.a===1);
     if(off>0){jumps++;assert(!trapNow,'jumped-over trap fired s='+s+' rev='+rev);assert(!td.used,'jumped-over trap consumed')}
     else{before++;assert(td.used,'trap before jump point must fire first (p ascending)')}
     hit=true;break}
    if(sd.used)break}
   }}
 assert(jumps>100&&before>50,'jump cases '+jumps+' '+before)}
// 장치 배열 순서를 뒤집어도 결과 동일 (참가자 번호 순서 무관)
for(let s=1;s<=40;s++){const c=cfg(s*31,10);const A=E.createRace(c),B=E.createRace(JSON.parse(JSON.stringify(c)));B.devices.reverse();
 E.advanceTo(A,1e9);E.advanceTo(B,1e9);assert.equal(JSON.stringify(A.events),JSON.stringify(B.events),'device order s='+s);assert.deepStrictEqual(E.summary(A),E.summary(B))}

// ── 버그 B: 잠긴 조각은 CHAOS가 변형하지 않음, S.tiles[i].locked 노출
{const locked=[true,false,true,false,true,false,true,false,true];let remixes=0;
 for(let s=1;s<=30;s++){const c=cfg(s,6,{locked});const S=E.createRace(c);S.tiles.forEach((t,i)=>assert.equal(t.locked,locked[i]));const v0=S.tiles.map(t=>t.variant);E.advanceTo(S,1e9);
  for(const e of S.events)if(e.k==='remix'){remixes++;assert(!locked[e.tile],'locked tile remixed')}
  S.tiles.forEach((t,i)=>{if(locked[i])assert.equal(t.variant,v0[i])})}
 assert(remixes>20,'remix happened '+remixes);
 const all=E.createRace(cfg(5,5,{locked:Array(9).fill(true)}));E.advanceTo(all,1e9);assert(!all.events.some(e=>e.k==='remix'),'all locked: no remix');
 const none=E.createRace(cfg(5,5));assert(none.tiles.every(t=>t.locked===false))}

// ── remixTile
{const c=cfg(77,6,{chaos:false});c.locked=[false,false,false,true,false,false,false,false,false];
 const A=E.createRace(c),B=E.createRace(JSON.parse(JSON.stringify(c)));
 assert.equal(E.remixTile(A,3),false,'locked');assert.equal(E.remixTile(A,0),false,'reached (start tile)');assert.equal(E.remixTile(A,9),false);assert.equal(E.remixTile(A,-1),false);assert.equal(E.remixTile(A,1.5),false);
 E.advanceTo(A,6);E.advanceTo(B,6);const lead=Math.max(...A.cars.map(x=>x.p*9));const v=A.tiles[7].variant;
 assert.equal(E.remixTile(A,7),true);assert.equal(E.remixTile(B,7),true);assert.notEqual(A.tiles[7].variant,v);assert.equal(A.tiles[7].variant,B.tiles[7].variant,'remixTile deterministic');
 const last=A.events[A.events.length-1];assert(last.k==='remix'&&last.tile===7&&last.manual===true);assert(A.tiles[7].flash>A.t);
 const reached=Math.floor(lead+.08);assert.equal(E.remixTile(A,reached),false,'tile reached by a car');
 E.advanceTo(A,1e9);E.advanceTo(B,1e9);assert.equal(JSON.stringify(A.events),JSON.stringify(B.events));assert.equal(E.remixTile(A,8),false,'done')}

// ── 10대: 차선이 노면(폭 25, 차 폭 10) 안, 서로 다른 차선
for(let n=1;n<=10;n++){const S=E.createRace(cfg(3,n));const ls=S.cars.map(c=>c.lane);for(const l of ls)assert(Math.abs(l)+5<=12.5+1e-9,'lane '+n+' '+l);assert.equal(new Set(ls.map(l=>l.toFixed(6))).size,n,'distinct lanes')}
{const c=cfg(1234,10,{dev:i=>[{type:'trap',sector:i%3},{type:'shortcut',sector:i%3},{type:'shield'}][i%3]});const S=E.createRace(c);E.advanceTo(S,1e9);assert.equal(S.finished.length,10);assert(S.t<120,'10-car race length '+S.t)}

// ── 방어막: 첫 트랩(설정에 따라 미사일)을 1회 막음
{let trapBlocks=0,missileBlocks=0;const saved=Object.assign({},E.SHIELD);
 for(const missile of [false,true]){E.SHIELD.missile=missile;
  for(let s=1;s<=60;s++){const c=cfg(s*13,8,{dev:i=>i%2?{type:'shield',sector:2}:{type:'trap',sector:i%3}});const S=E.createRace(c);
   S.cars.forEach((car,i)=>assert.equal(car.shield,i%2===1,'shield field'));E.advanceTo(S,1e9);
   const blocks=S.events.filter(e=>e.k==='block');const per={};
   for(const e of blocks){assert(e.a%2===1,'block owner has shield');per[e.a]=(per[e.a]||0)+1;assert(e.by==='trap'||e.by==='missile'||e.by==='bolt');assert(typeof e.b==='number');
    if(e.by==='trap'){trapBlocks++;const d=S.devices.find(d=>d.owner===e.b);assert(d.used&&d.blocked&&d.victim===e.a,'blocked trap consumed')}
    if(e.by==='missile'){missileBlocks++;assert(E.SHIELD.missile)}}
   for(const k in per)assert(per[k]<=E.SHIELD.charges,'charges');
   for(const k in per)if(per[k]>=E.SHIELD.charges)assert.equal(S.cars[k].shield,false,'shield spent');
   for(const e of S.events)if(e.k==='trap'&&e.b%2===1)assert(blocks.some(x=>x.a===e.b&&x.t<=e.t),'shielded car hit by trap before its shield was used')}}
 Object.assign(E.SHIELD,saved);assert(trapBlocks>0,'trap block');assert(missileBlocks>0,'missile block (SHIELD.missile=true)');
 // 엉뚱한 차(wild)로 걸려도 방어막 적용
 const sw=E.SECRET.wild;E.SECRET.wild=1;let wildBlock=0;
 for(let s=1;s<=60;s++){const S=E.createRace(cfg(s,4,{battle:false,dev:i=>i===0?{type:'trap',sector:0}:{type:'shield'}}));E.advanceTo(S,1e9);if(S.events.some(e=>e.k==='block'&&e.by==='trap'))wildBlock++;assert(!S.events.some(e=>e.k==='trap'),'all others shielded')}
 E.SECRET.wild=sw;assert(wildBlock>50,'wild trap blocked '+wildBlock)}

// ── recap 형식
{const okT=['hit','wild','blocked','unused'],okS=['jump','deadend','unused'],okH=['blocked','unused'];const seen={};
 for(let s=1;s<=60;s++){const c=cfg(s*7,8,{dev:i=>[{type:'trap',sector:i%3},{type:'shortcut',sector:(i+1)%3},{type:'shield'},null][i%4]});const S=E.createRace(c);
  assert.deepStrictEqual(S.recap,[]);E.advanceTo(S,1e9);assert(Array.isArray(S.recap));
  const owners=c.racers.map((r,i)=>r.device?i:-1).filter(i=>i>=0);assert.deepStrictEqual(S.recap.map(r=>r.owner),owners,'one entry per device owner, idx order');
  const rk=E.standings(S).map(x=>x.idx);
  for(const r of S.recap){assert.equal(r.type,c.racers[r.owner].device.type);assert.equal(r.ownerRank,rk.indexOf(r.owner)+1);seen[r.type+':'+r.result]=1;
   for(const v of Object.values(r))assert(typeof v!=='string'||v.length<12,'no prose');
   if(r.type==='trap'){assert(okT.includes(r.result));assert.equal(r.sector,c.racers[r.owner].device.sector);
    if(r.result!=='unused'){assert(r.victim>=0&&r.victim<8&&r.victim!==r.owner);assert(r.rankBefore>=1&&r.rankBefore<=8);assert.equal(r.victimRank,rk.indexOf(r.victim)+1);assert.equal(typeof r.wild,'boolean');assert.equal(r.result==='wild',r.wild&&r.result!=='blocked')}}
   else if(r.type==='shortcut'){assert(okS.includes(r.result));if(r.result==='jump')assert(r.rankBefore>=1&&r.rankAfter>=1&&r.rankAfter<=r.rankBefore);if(r.result==='deadend')assert(r.rankBefore>=1)}
   else{assert(okH.includes(r.result));assert.equal(r.sector,null);if(r.result==='blocked'){assert(['trap','missile','bolt'].includes(r.by));assert(r.attacker>=0&&r.attacker!==r.owner);assert(r.blocks.length>=1)}}}}
 // 트랩이 걸리면 주인 가속(steal)
 {const S=E.createRace(cfg(11,5,{battle:false,dev:i=>i===0?{type:'trap',sector:0}:null}));while(!S.done&&!S.events.some(e=>e.k==='trap'))E.step(S);assert(S.cars[0].boost>S.t,'trap owner boost')}
 for(const k of ['trap:hit','trap:wild','trap:blocked','shortcut:jump','shortcut:deadend','shield:blocked'])assert(seen[k],'recap case '+k)}

const t0=Date.now();const X=E.createRace(cfg(99,50));E.advanceTo(X,1e9);
const t1=Date.now();let ten=0;for(let s=0;s<50;s++){const Y=E.createRace(cfg(s,10));E.advanceTo(Y,1e9);ten++}
// 조각 수 확장: 모든 배치·모든 변형에서 길이 이어지고, 경주가 끝나며, 같은 설계도면 결과가 같음
for(const N of [9,12,15,18,20,24]){const L=E.layoutOf(N);assert.equal(L.order.length,N);
 for(let v=0;v<E.VARIANTS;v++)for(let i=0;i<N-1;i++){const a=E.tileGeom(i,v,N).routes[0].points[200],b=E.tileGeom(i+1,v,N).routes[0].points[0];assert(Math.abs(a.x-b.x)+Math.abs(a.y-b.y)<1e-6,'layout gap '+N+':'+i)}
 const tiles=E.randomTiles(N*31,null,null,N);assert.equal(tiles.length,N);assert(tiles.filter(v=>v>=E.FORK2).length>=Math.max(2,Math.round(N*2/9)));
 const cfg={seed:N*7,tiles,chaos:true,battle:true,racers:[...Array(6)].map((_,k)=>({id:k,name:k,device:{type:['trap','shortcut','shield'][k%3],sector:k%3}}))};
 const A=E.createRace(cfg),B=E.createRace(JSON.parse(JSON.stringify(cfg)));E.advanceTo(A,1e9);let t=0;while(!B.done){t+=.37;E.advanceTo(B,t)}assert(A.done&&A.finished.length===6);assert.deepStrictEqual(E.summary(A),E.summary(B))}
// 맵 트랩·아이템 끄기: 결정적이고, 구간별 확률대로 걸리며, 번개·미사일이 꺼짐
{const racers=[...Array(8)].map((_,k)=>({id:k,name:k,device:null}));const cfg={seed:42,tiles:E.randomTiles(42),chaos:true,battle:false,bolt:false,hazards:[.2,.5,.8],racers};
 const A=E.createRace(cfg),B=E.createRace(JSON.parse(JSON.stringify(cfg)));E.advanceTo(A,1e9);let tt=0;while(!B.done){tt+=.29;E.advanceTo(B,tt)}assert.deepStrictEqual(E.summary(A),E.summary(B));
 assert.equal(A.events.filter(e=>e.k==='bolt'||e.k==='hit').length,0,'items off');assert(A.hazards.every(z=>z.hits+z.miss===8),'every car passes every map trap');
 let h=[0,0,0],n=[0,0,0];for(let s=1;s<=120;s++){const S=E.createRace({...cfg,seed:s});E.advanceTo(S,1e9);S.hazards.forEach((z,k)=>{h[k]+=z.hits;n[k]+=z.hits+z.miss})}
 h.forEach((x,k)=>assert(Math.abs(x/n[k]-E.HAZARD.chance[k])<.07,'hazard chance '+k))}
console.log('PASS engine',JSON.stringify(tot),'longest race',maxT.toFixed(1)+'s','| 50-car full sim',t1-t0+'ms','steps',X.steps,'| 10-car race avg',((Date.now()-t1)/ten).toFixed(1)+'ms');
