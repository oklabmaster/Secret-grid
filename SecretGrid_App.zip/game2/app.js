/* SECRET GRID 행사판 — 화면 연결과 진행 (실장)
 * 엔진(SGEngine) · 대회(SGTournament) · 그리기(SGRender)를 화면에 연결합니다.
 * 진행 상태는 브라우저에 저장되어, 새로고침해도 이어서 할 수 있습니다.
 */
(function(){
'use strict';
const E=window.SGEngine,TR=window.SGTournament,R=window.SGRender,$=id=>document.getElementById(id);
if(new URLSearchParams(location.search).get('mock'))return; // 디자인 목업 모드
const SAVE_KEY='secret-grid-v5',SECRET_SECONDS=15,SPEED=Math.max(1,Math.min(20,+new URLSearchParams(location.search).get('speed')||1)); // speed: 점검용 빨리 감기
const store={get(){try{return JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch(e){return null}},set(v){try{localStorage.setItem(SAVE_KEY,JSON.stringify(v))}catch(e){}},clear(){try{localStorage.removeItem(SAVE_KEY)}catch(e){}}};
const tpl=id=>$(id).content.firstElementChild.cloneNode(true);

/* ── 커스텀 설정 ──
 * 목록 하나로 화면과 적용을 함께 관리. key는 '엔진객체.이름' 또는 'APP.이름'.
 * triple: 초반·중반·후반 3칸, scale: 화면 표시 배율(확률 0.25 → 25%), battle: 공격 ON용 값도 같이 바꿈 */
const CUSTOM_KEY='secret-grid-custom';
const CUSTOM=[
 {g:'경주',items:[
  {k:'RACE.speed',l:'차 기본 속도',u:'',min:40,max:300,step:5,h:'클수록 경주가 빨리 끝나요 (기본 115)'},
  {k:'RACE.remixEvery',l:'랜덤 변형 간격',u:'초',min:1,max:60,step:1},
  {k:'RACE.slowFactor',l:'감속 중 속도',u:'%',scale:100,min:0,max:100,step:5,h:'트랩·미사일·번개에 걸렸을 때 원래 속도의 몇 %로 달릴지'},
  {k:'RACE.wobble',l:'속도 흔들림',u:'%',scale:100,min:0,max:50,step:1,h:'차마다 빨라졌다 느려졌다 하는 정도'}]},
 {g:'트랩',ico:'trap',items:[
  {k:'SECRET.slow',l:'상대 감속 시간',u:'초',triple:true,min:0,max:30,step:.1},
  {k:'SECRET.steal',l:'걸었을 때 내 차 가속 시간',u:'초',triple:true,battle:true,min:0,max:30,step:.1},
  {k:'SECRET.stealSpeed',l:'가속 배율',u:'배',min:1,max:3,step:.05},
  {k:'SECRET.wild',l:'엉뚱한 차가 걸릴 확률',u:'%',scale:100,min:0,max:100,step:1}]},
 {g:'지름길',ico:'shortcut',items:[
  {k:'SECRET.skip',l:'점프 거리',u:'%',triple:true,battle:true,scale:100,min:0,max:50,step:.1,h:'트랙 전체 길이 대비'},
  {k:'SECRET.deadEnd',l:'막다른 길 확률',u:'%',scale:100,min:0,max:100,step:1},
  {k:'SECRET.deadStun',l:'막다른 길에서 멈추는 시간',u:'초',min:0,max:20,step:.1}]},
 {g:'방어막',ico:'shield',items:[
  {k:'SHIELD.charges',l:'막는 횟수',u:'회',min:0,max:10,step:1},
  {k:'SHIELD.trap',l:'트랩 막기',bool:true},
  {k:'SHIELD.missile',l:'미사일도 막기',bool:true},
  {k:'SHIELD.bolt',l:'번개도 막기',bool:true}]},
 {g:'미사일 (미사일 공격이 켜져 있을 때)',ico:'missile',items:[
  {k:'ATTACK.charge',l:'게이지 충전 시간',u:'초',min:1,max:60,step:.5},
  {k:'ATTACK.catchup',l:'뒤처진 차 충전 보너스',u:'%',scale:100,min:0,max:300,step:5,h:'꼴찌가 1등보다 이만큼 더 빨리 충전'},
  {k:'ATTACK.range',l:'사거리',u:'px',min:10,max:400,step:5},
  {k:'ATTACK.stun',l:'맞으면 도는 시간',u:'초',min:0,max:10,step:.1},
  {k:'ATTACK.dodge',l:'피할 확률',u:'%',scale:100,min:0,max:100,step:1},
  {k:'ATTACK.immune',l:'맞은 뒤 무적 시간',u:'초',min:0,max:20,step:.5}]},
 {g:'꼴찌의 번개',ico:'bolt',items:[
  {k:'BOLT.on',l:'번개 사용',bool:true},
  {k:'BOLT.start',l:'첫 번개',u:'초',min:0,max:120,step:1},
  {k:'BOLT.every',l:'간격',u:'초',min:1,max:120,step:1},
  {k:'BOLT.stun',l:'선두가 멈추는 시간',u:'초',min:0,max:10,step:.1}]},
 {g:'맵 트랩',items:[
  {k:'HAZARD.chance',l:'걸릴 확률',u:'%',triple:true,scale:100,min:0,max:100,step:1,h:'트랩이 놓인 구간(초반·중반·후반)에 따라'},
  {k:'HAZARD.slow',l:'걸리면 느려지는 시간',u:'초',min:0,max:10,step:.1}]},
 {g:'연출 (경주 결과에는 영향 없음)',items:[
  {k:'APP.fxFinal',l:'결승 구간 연출',bool:true,h:'7·8·9번 조각에 1·2·3위가 모두 들어오면 확대·슬로모션'},
  {k:'APP.finalSlow',l:'결승 구간 슬로모션 속도',u:'%',min:10,max:100,step:5,h:'100이면 원래 속도'},
  {k:'APP.fx3d',l:'결승 구간 기울어진 중계 화면',bool:true},
  {k:'APP.fxImpact',l:'미사일·번개 하이라이트',bool:true,h:'중반 이후 1위가 맞아 1·2위가 바뀔 만할 때 시간 느려짐·확대·흔들림'},
  {k:'APP.fxIntro',l:'출발 카메라 연출',bool:true}]},
 {g:'대회 진행',note:'점수·결승 설정은 새로 시작하는 대회부터 적용돼요.',items:[
  {k:'APP.secretSeconds',l:'비밀 장치 고르는 시간',u:'초',min:5,max:120,step:1},
  {k:'APP.pointsHeat',l:'예선 순위 점수',list:true,h:'1위부터 쉼표로. 비우면 자동(5대 이하 10,7,5,3,1)'},
  {k:'APP.pointsFinal',l:'결승 순위 점수',list:true,h:'비우면 12,9,7,5,4,3,2,1'},
  {k:'APP.finalPer',l:'결승 진출 팀 수',u:'팀',min:1,max:8,step:1,h:'조가 둘이면 조마다 이만큼'},
  {k:'APP.finals',l:'결승 판 수',u:'판',min:0,max:4,step:1,h:'0이면 결승 없이 예선 합계로 끝'}]}];
const APP={secretSeconds:15,pointsHeat:'',pointsFinal:'',finalPer:4,finals:2,fxFinal:true,finalSlow:50,fx3d:true,fxImpact:true,fxIntro:true};
const ENG={RACE:E.RACE,ATTACK:E.ATTACK,SECRET:E.SECRET,BOLT:E.BOLT,SHIELD:E.SHIELD,HAZARD:E.HAZARD,APP};
const DEFAULTS=JSON.parse(JSON.stringify({RACE:E.RACE,ATTACK:E.ATTACK,SECRET:E.SECRET,BOLT:E.BOLT,SHIELD:E.SHIELD,HAZARD:E.HAZARD,APP}));
const custom={load(){try{return JSON.parse(localStorage.getItem(CUSTOM_KEY)||'{}')||{}}catch(e){return{}}},save(v){try{localStorage.setItem(CUSTOM_KEY,JSON.stringify(v))}catch(e){}}};
// 화면에 보여줄 기본값: 공격 ON용 값이 따로 있으면 그것(기본이 공격 ON이므로)
function defaultOf(it){const [o,n]=it.k.split('.');if(it.battle&&DEFAULTS.SECRET.battle&&DEFAULTS.SECRET.battle[n]!==undefined)return DEFAULTS.SECRET.battle[n];return DEFAULTS[o][n]}
function applyCustom(){const c=custom.load();
 // 먼저 전부 기본값으로 되돌린 뒤, 바꾼 것만 덮어씀
 for(const o in DEFAULTS){const src=JSON.parse(JSON.stringify(DEFAULTS[o]));for(const n in src)ENG[o][n]=src[n]}
 for(const g of CUSTOM)for(const it of g.items){if(!(it.k in c))continue;const [o,n]=it.k.split('.');ENG[o][n]=c[it.k];if(it.battle&&ENG.SECRET.battle)ENG.SECRET.battle[n]=c[it.k]}}
const secretSeconds=()=>Math.max(5,APP.secretSeconds|0||15);
const parseList=t=>String(t||'').split(/[,\s]+/).filter(Boolean).map(Number).filter(x=>isFinite(x)&&x>=0);
function same(a,b){const r=v=>Array.isArray(v)?v.map(r):typeof v==='number'?Math.round(v*1e6)/1e6:v;return JSON.stringify(r(a))===JSON.stringify(r(b))}
function fmt(v,it){const x=it.scale?v*it.scale:v;return Math.round(x*1000)/1000}
function openCustom(){const c=custom.load(),body=$('custom-body'),keepTop=$('dlg-custom').open?body.scrollTop:0;body.replaceChildren();
 for(const g of CUSTOM){const sec=document.createElement('section');sec.className='cg';const h=document.createElement('h3');h.className='cg-h';if(g.ico){const i=document.createElement('i');i.className='ico ico-'+g.ico;i.setAttribute('aria-hidden','true');h.append(i)}h.append(document.createTextNode(g.g));sec.append(h);
  if(g.note){const p=document.createElement('p');p.className='cg-note';p.textContent=g.note;sec.append(p)}
  for(const it of g.items){const row=document.createElement('div');row.className='ci';row.dataset.k=it.k;const lab=document.createElement('div');lab.className='ci-label';lab.textContent=it.l;if(it.h){const sm=document.createElement('small');sm.textContent=it.h;lab.append(sm)}
   const box=document.createElement('div');box.className='ci-inputs';const def=defaultOf(it),cur=it.k in c?c[it.k]:def;
   const mark=()=>lab.classList.toggle('is-changed',!same(readItem(row,it),def));
   if(it.bool){const l=document.createElement('label');l.className='switch';const inp=document.createElement('input');inp.type='checkbox';inp.checked=!!cur;inp.setAttribute('aria-label',it.l);const ui=document.createElement('span');ui.className='switch-ui';l.append(inp,ui);box.append(l);inp.onchange=mark}
   else if(it.list){const inp=document.createElement('input');inp.type='text';inp.value=Array.isArray(cur)?cur.join(', '):cur||'';inp.placeholder='자동';inp.setAttribute('aria-label',it.l);box.append(inp);inp.oninput=mark}
   else{const vals=it.triple?cur:[cur];vals.forEach((v,j)=>{const w=document.createElement('label');w.className='ci-num';const inp=document.createElement('input');inp.type='number';inp.min=it.min;inp.max=it.max;inp.step=it.step;inp.value=fmt(v,it);inp.setAttribute('aria-label',it.l+(it.triple?' '+['초반','중반','후반'][j]:''));inp.oninput=mark;w.append(inp);if(it.triple){const sm=document.createElement('small');sm.textContent=['초반','중반','후반'][j];w.append(sm)}box.append(w)});
    const u=document.createElement('span');u.className='ci-unit';u.textContent=it.u||'';box.append(u)}
   row.append(lab,box);sec.append(row);mark()}
  body.append(sec)}
 countChanged();if(!$('dlg-custom').open)$('dlg-custom').showModal();body.scrollTop=keepTop}
function readItem(row,it){if(it.bool)return row.querySelector('input').checked;if(it.list){const v=parseList(row.querySelector('input').value);return v.length?v:''}
 const nums=[...row.querySelectorAll('input[type=number]')].map(inp=>{let x=parseFloat(inp.value);if(!isFinite(x))x=parseFloat(inp.min)||0;x=Math.max(+inp.min,Math.min(+inp.max,x));return Math.round((it.scale?x/it.scale:x)*1e6)/1e6});return it.triple?nums:nums[0]}
function countChanged(){const n=$('custom-body').querySelectorAll('.is-changed').length;$('custom-changed').textContent=n?`바꾼 항목 ${n}개`:'모두 기본값'}
$('custom-body').addEventListener('input',()=>countChanged());$('custom-body').addEventListener('change',()=>countChanged());
$('custom-save').onclick=()=>{const out={};for(const g of CUSTOM)for(const it of g.items){const row=$('custom-body').querySelector(`[data-k="${it.k}"]`);const v=readItem(row,it);if(!same(v,defaultOf(it)))out[it.k]=v}custom.save(out);applyCustom();syncRuleText();$('dlg-custom').close();if(!$('screen-start').hidden)$('tour-plan').textContent=planText(tourCount,+$('tour-heats').value);if(!$('screen-lobby').hidden&&st)renderLobby()};
$('custom-cancel').onclick=()=>$('dlg-custom').close();
$('dlg-custom').addEventListener('close',hideKeyboard);
$('custom-reset').onclick=()=>{if($('custom-reset').dataset.armed){delete $('custom-reset').dataset.armed;custom.save({});applyCustom();syncRuleText();openCustom();$('custom-reset').textContent='모두 기본값으로';return}$('custom-reset').dataset.armed='1';$('custom-reset').textContent='한 번 더 누르면 초기화';setTimeout(()=>{if($('custom-reset').dataset.armed){delete $('custom-reset').dataset.armed;$('custom-reset').textContent='모두 기본값으로'}},3000)};
$('start-custom').onclick=openCustom;$('lobby-custom').onclick=openCustom;
applyCustom();syncRuleText();
const rint=()=>1+Math.floor(Math.random()*2147483646);
const DEVICE_NAME={trap:'트랩',shortcut:'지름길',shield:'방어막'},SECTOR_NAME=['초반','중반','후반'];

/* ── 상태 ── */
let st=null; // {mode:'tour'|'quick', T, quick:{names}, tiles, locked, settings:{chaos,battle}, pending:{seed,devices}|null}
function fresh(mode){return{mode,T:null,quick:null,tiles:E.randomTiles(rint()),locked:Array(9).fill(false),settings:{chaos:true,battle:true,devices:true,bolt:true},hazards:[],pending:null}}
function save(){if(st)store.set(st)}

// 이번 판에 나가는 팀: [{id, name, no(팀 번호 1~10)}]
function raceTeams(){if(st.mode==='tour'){const race=TR.current(st.T);if(!race)return[];return race.teams.map(id=>TR.teamOf(st.T,id))}
 return st.quick.names.map((name,i)=>({id:'q'+(i+1),name,no:i+1}))}
function stageLabel(){if(st.mode==='quick')return'빠른 경기';const race=TR.current(st.T);return race?TR.label(st.T,race):'대회 종료'}
function teamIdx(teams){return teams.map(t=>t.no-1)}
// 화면을 바꿀 때만 맨 위로 (같은 화면을 다시 그릴 때는 스크롤 위치 유지: 인원수 변경·설정 저장 등)
let curScreen='';
function show(id){const changed=id!==curScreen;curScreen=id;document.querySelectorAll('.screen').forEach(s=>s.hidden=s.id!==id);document.body.classList.toggle('is-broadcast',id==='screen-race'||id==='screen-final');if(changed){hideKeyboard();window.scrollTo(0,0)}}
// 입력칸에서 포커스를 빼서 폰 키보드를 내림
function hideKeyboard(){const a=document.activeElement;if(a&&a!==document.body&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName))a.blur()}
const isTyping=()=>{const a=document.activeElement;return!!a&&(a.tagName==='TEXTAREA'||(a.tagName==='INPUT'&&!/^(checkbox|radio|button|submit|range)$/.test(a.type)))}
function plate(el,no){R.paintPlate(el,no-1)}

/* ── 1) 시작 화면 ── */
const DEFAULT_TEAMS=['1팀','2팀','3팀','4팀','5팀','6팀','7팀','8팀','9팀','10팀'];
let tourCount=10,quickCount=4,tourNames=DEFAULT_TEAMS.slice(),quickNames=['레이서1','레이서2','레이서3','레이서4','레이서5','레이서6','레이서7','레이서8','레이서9','레이서10'];
function readInputs(box,arr){box.querySelectorAll('input.name').forEach((inp,i)=>{arr[i]=inp.value.trim().slice(0,10)})}
function fillInputs(box,n,arr,prefix){box.replaceChildren();for(let i=0;i<n;i++){const r=tpl('tpl-team-input');R.paintPlate(r.querySelector('.plate'),i);const inp=r.querySelector('input');inp.value=arr[i]||'';inp.placeholder=`${i+1}${prefix}`;inp.setAttribute('aria-label',`${i+1}${prefix} 이름`);box.append(r)}}
function planText(n,h){const F=APP.finals|0,fp=Math.max(1,APP.finalPer|0||4),fin=F>0&&n>=5;
 if(n>8){const a=Math.ceil(n/2);return`A조 ${a}팀 · B조 ${n-a}팀이 번갈아 ${h}판씩`+(fin?` → 조별 상위 ${Math.min(fp,n-a)}팀 결승 ${F}판`:' · 누적 점수로 순위 결정')}
 if(fin)return`${n}팀이 함께 ${h}판 → 누적 상위 ${Math.min(fp,n-1)}팀 결승 ${F}판`;return`${n}팀이 함께 ${h}판 · 누적 점수로 순위 결정`}
// 규칙 안내 글을 현재 설정 숫자에 맞춤
function syncRuleText(){const q=(sel)=>document.querySelector(sel);const chaosSmall=q('#opt-chaos')&&q('#opt-chaos').closest('label').querySelector('small');if(chaosSmall)chaosSmall.textContent=`${E.RACE.remixEvery}초마다 아직 차가 안 간 조각 하나가 바뀝니다`;
 const bs=q('#opt-bolt')&&q('#opt-bolt').closest('label').querySelector('small');if(bs)bs.textContent=`${E.BOLT.start}초부터 ${E.BOLT.every}초마다 꼴찌가 선두를 멈춤`;
 const bolt=q('.rule .ico-bolt');if(bolt){const p=bolt.parentElement.querySelector('p');if(p)p.textContent=E.BOLT.on?`${E.BOLT.start}초부터 ${E.BOLT.every}초마다 꼴찌가 선두를 ${E.BOLT.stun}초 멈춥니다.`:'이번 설정에서는 번개를 쓰지 않아요.'}
 const sh=q('.rule .ico-shield');if(sh){const p=sh.parentElement.querySelector('p'),what=[E.SHIELD.trap?'트랩':'',E.SHIELD.missile?'미사일':'',E.SHIELD.bolt?'번개':''].filter(Boolean).join('·')||'아무것도';if(p)p.textContent=`나에게 오는 ${what} 공격을 ${E.SHIELD.charges}번 막습니다.`}
 const dev=q('[data-device="shield"] small');if(dev)dev.textContent=E.SHIELD.missile||E.SHIELD.bolt?`첫 공격 ${E.SHIELD.charges}번 막기`:`첫 트랩 ${E.SHIELD.charges}번 막기`}
function renderStart(){show('screen-start');readInputs($('tour-teams'),tourNames);readInputs($('quick-names'),quickNames);
 $('tour-count').textContent=tourCount;$('quick-count').textContent=quickCount;fillInputs($('tour-teams'),tourCount,tourNames,'팀');fillInputs($('quick-names'),quickCount,quickNames,'번');
 $('tour-plan').textContent=planText(tourCount,+$('tour-heats').value);
 $('tour-count-minus').disabled=tourCount<=2;$('tour-count-plus').disabled=tourCount>=10;$('quick-count-minus').disabled=quickCount<=2;$('quick-count-plus').disabled=quickCount>=10;
 const saved=store.get(),can=saved&&saved.mode==='tour'&&saved.T&&saved.T.stage!=='done';$('start-resume').hidden=!can;
 if(can){st=null;$('start-resume-info').textContent=`저장된 대회: ${saved.T.results.length}판 진행 · 다음은 ${TR.label(saved.T,TR.current(saved.T))}`}}
$('tour-count-minus').onclick=()=>{readInputs($('tour-teams'),tourNames);tourCount=Math.max(2,tourCount-1);renderStart()};
$('tour-count-plus').onclick=()=>{readInputs($('tour-teams'),tourNames);tourCount=Math.min(10,tourCount+1);renderStart()};
$('quick-count-minus').onclick=()=>{readInputs($('quick-names'),quickNames);quickCount=Math.max(2,quickCount-1);renderStart()};
$('quick-count-plus').onclick=()=>{readInputs($('quick-names'),quickNames);quickCount=Math.min(10,quickCount+1);renderStart()};
$('tour-heats').onchange=()=>{$('tour-plan').textContent=planText(tourCount,+$('tour-heats').value)};
$('tour-start').onclick=()=>{readInputs($('tour-teams'),tourNames);const names=tourNames.slice(0,tourCount).map((n,i)=>n||`${i+1}팀`);
 st=fresh('tour');st.T=TR.create({teams:names,heats:+$('tour-heats').value,finals:APP.finals,finalPer:APP.finalPer,pointsHeat:parseList(APP.pointsHeat),pointsFinal:parseList(APP.pointsFinal)});save();renderLobby()};
$('quick-start').onclick=()=>{readInputs($('quick-names'),quickNames);st=fresh('quick');st.quick={names:quickNames.slice(0,quickCount).map((n,i)=>n||`레이서${i+1}`)};save();renderLobby()};
$('start-resume').querySelector('button').onclick=()=>{st=store.get();if(!st)return renderStart();if(st.pending)return openRace();renderLobby()};

/* ── 2) 대기·트랙 화면 ── */
const lobbyR=R.createRenderer($('lobby-canvas'));let selectedTile=-1;
function lobbyView(){const teams=raceTeams();return{mode:'preview',selectedTile,count:teams.length,teamIdx:teamIdx(teams),hazards:st.hazards||[]}}
function drawLobby(){lobbyR.setTrack(st.tiles,{locked:st.locked,selectedTile});lobbyR.drawFrame(null,lobbyView())}
function renderLobby(){if(!st)return renderStart();if(st.mode==='tour'&&st.T.stage==='done')return renderAward();show('screen-lobby');lobbyR.resize();
 const teams=raceTeams(),race=st.mode==='tour'?TR.current(st.T):null;
 $('lobby-stage').textContent=stageLabel();
 $('lobby-sub').textContent=st.mode==='quick'?`${teams.length}명 출전`:race.stage==='final'?`결승 진출 ${teams.length}팀`:`${TR.groupLabel(st.T,race.group)?TR.groupLabel(st.T,race.group)+' ':''}${teams.map(t=>t.no).join('·')}팀 출전`;
 const box=$('lobby-teams');box.replaceChildren();for(const t of teams){const e=tpl('tpl-entry');plate(e.querySelector('.plate'),t.no);e.querySelector('.entry-name').textContent=t.name;box.append(e)}
 $('lobby-size').value=String(st.tiles.length);$('opt-chaos').checked=st.settings.chaos;$('opt-battle').checked=st.settings.battle;$('opt-devices').checked=st.settings.devices!==false;$('opt-bolt').checked=st.settings.bolt!==false;itemsUI();hazardInfo();$('lobby-board').hidden=st.mode!=='tour';
 tileInfo();drawLobby()}
function tileInfo(){const ok=selectedTile>=0;$('lobby-tile-info').textContent=ok?`${selectedTile+1}번 조각 · ${E.shapeNames[st.tiles[selectedTile]]}${st.locked[selectedTile]?' · 고정됨':''}`:'지도에서 조각을 눌러 고르세요';
 $('lobby-remix').disabled=!ok||st.locked[selectedTile];$('lobby-lock').disabled=!ok;const on=ok&&st.locked[selectedTile];$('lobby-lock').setAttribute('aria-pressed',String(on));$('lobby-lock').textContent=on?'고정 풀기':'고정'}
$('lobby-canvas').addEventListener('click',e=>{if(hazardMode)return placeHazard(e);const i=lobbyR.pick(e.clientX,e.clientY);if(i>=0){selectedTile=i;tileInfo();drawLobby()}});
/* 아이템 스위치: 비밀 장치·미사일·번개를 따로 켜고 끔. 셋 다 끄면 아이템 없는 순수 레이스 */
function itemsUI(){const S0=st.settings,dev=S0.devices!==false,none=!dev&&!S0.battle&&S0.bolt===false;
 $('lobby-secret').textContent=dev?'이 화면에서 차례로 고르기':'바로 출발';$('lobby-phone').hidden=!dev;$('lobby-secret').classList.toggle('btn-primary',!dev);$('lobby-secret').classList.toggle('btn-secondary',dev);$('items-note').hidden=!none;
 document.querySelectorAll('.rule').forEach(r=>{const ic=r.querySelector('.ico');if(!ic)return;const k=[...ic.classList].find(c=>c.startsWith('ico-'));r.classList.toggle('is-off',(['ico-trap','ico-shortcut','ico-shield'].includes(k)&&!dev)||(k==='ico-bolt'&&S0.bolt===false))})}
$('opt-devices').onchange=()=>{st.settings.devices=$('opt-devices').checked;save();itemsUI()};
$('opt-bolt').onchange=()=>{st.settings.bolt=$('opt-bolt').checked;save();itemsUI()};
/* 맵 트랩: 진행자가 지도 길 위를 눌러 놓고, 다시 누르면 뺌 (최대 12개) */
let hazardMode=false;const HAZARD_MAX=12;
function hazardInfo(){const n=(st.hazards||[]).length,ch=E.HAZARD.chance.map(x=>Math.round(x*100)+'%').join(' · ');$('lobby-hazard-info').textContent=hazardMode?`길 위를 누르면 트랩이 놓이고, 트랩을 다시 누르면 빠져요. (${n}/${HAZARD_MAX}개)`:`맵 트랩 ${n}개 · 지나가는 모든 차가 초반·중반·후반 ${ch} 확률로 걸려 ${E.HAZARD.slow}초 느려져요.`;
 $('lobby-hazard').setAttribute('aria-pressed',String(hazardMode));$('lobby-hazard').textContent=hazardMode?'⚠ 트랩 놓기 끝내기':'⚠ 맵 트랩 놓기';$('lobby-canvas').classList.toggle('is-hazard',hazardMode);$('lobby-hazard-clear').disabled=!n}
function nearestOnTrack(x,y){const N=st.tiles.length;let best=null;for(let i=0;i<N;i++){const routes=E.tileGeom(i,st.tiles[i],N).routes;routes.forEach(r=>{for(let j=0;j<=200;j+=2){const q=r.points[j],d=(q.x-x)*(q.x-x)+(q.y-y)*(q.y-y);if(!best||d<best.d)best={d,p:(i+j/200)/N,x:q.x,y:q.y}}})}return best}
function placeHazard(e){const pt=lobbyR.toLogical(e.clientX,e.clientY),hit=nearestOnTrack(pt.x,pt.y);if(!hit||hit.d>40*40)return;st.hazards=st.hazards||[];
 const fake={tiles:st.tiles.map((v,i)=>({routes:E.tileGeom(i,v,st.tiles.length).routes}))};
 const near=st.hazards.findIndex(p=>{const a=E.at(fake,p,0);return(a.x-pt.x)**2+(a.y-pt.y)**2<26*26||Math.abs(p-hit.p)<.004});
 if(near>=0)st.hazards.splice(near,1);else{if(hit.p<.02||hit.p>.97||st.hazards.length>=HAZARD_MAX)return;st.hazards.push(Math.round(hit.p*1e5)/1e5)}
 save();hazardInfo();drawLobby()}
$('lobby-hazard').onclick=()=>{hazardMode=!hazardMode;hazardInfo()};
$('lobby-hazard-clear').onclick=()=>{st.hazards=[];save();hazardInfo();drawLobby()};
$('lobby-size').onchange=()=>{const N=+$('lobby-size').value;if(N===st.tiles.length)return;st.tiles=E.randomTiles(rint(),null,null,N);st.locked=Array(N).fill(false);selectedTile=-1;save();tileInfo();lobbyR.resize();drawLobby()};
$('lobby-shuffle').onclick=()=>{st.tiles=E.randomTiles(rint(),st.tiles,st.locked);save();tileInfo();drawLobby()};
$('lobby-remix').onclick=()=>{if(selectedTile<0||st.locked[selectedTile])return;const old=st.tiles[selectedTile];let v=Math.floor(Math.random()*(E.VARIANTS-1));if(v>=old)v++;st.tiles[selectedTile]=v;save();tileInfo();drawLobby()};
$('lobby-lock').onclick=()=>{if(selectedTile<0)return;st.locked[selectedTile]=!st.locked[selectedTile];save();tileInfo();drawLobby()};
$('opt-chaos').onchange=()=>{st.settings.chaos=$('opt-chaos').checked;save()};
$('opt-battle').onchange=()=>{st.settings.battle=$('opt-battle').checked;save()};
$('lobby-home').onclick=()=>{save();renderStart()};
$('lobby-board').onclick=()=>renderBoard('screen-lobby');
$('lobby-demo').onclick=()=>{hazardMode=false;st.pending={seed:rint(),devices:{},practice:true};openRace()};
$('lobby-secret').onclick=()=>{hazardMode=false;if(st.settings.devices===false){st.pending={seed:rint(),devices:{}};save();return openRace()}startSecret()};
addEventListener('resize',()=>{if(!$('screen-lobby').hidden){lobbyR.resize();drawLobby()}if(!$('screen-race').hidden&&raceR){raceR.resize();if(S)raceR.drawFrame(S,raceView())}});

/* ── 3) 몰래 설치 ── */
const dlg=$('dlg-secret');dlg.addEventListener('cancel',e=>e.preventDefault());
let sec=null; // {teams, k, devices, type, sector, left, timer}
function startSecret(){sec={teams:raceTeams(),k:0,devices:{},type:'trap',sector:0,left:secretSeconds(),timer:null};if(!dlg.open)dlg.showModal();handoff()}
function step(name){$('secret-handoff').hidden=name!=='handoff';$('secret-choose').hidden=name!=='choose';$('secret-confirm').hidden=name!=='confirm'}
function handoff(){const t=sec.teams[sec.k];clearInterval(sec.timer);sec.type='trap';sec.sector=0;sec.left=secretSeconds();
 $('secret-progress').textContent=`${sec.k+1} / ${sec.teams.length}팀`;plate($('secret-plate'),t.no);$('secret-team').textContent=st.mode==='tour'&&t.name!==`${t.no}팀`?`${t.no}팀 ${t.name}`:t.name;step('handoff');$('secret-reveal').focus()}
function paintChoice(){document.querySelectorAll('[data-device]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.device===sec.type)));document.querySelectorAll('[data-sector]').forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.sector===sec.sector)));$('secret-sector-field').hidden=sec.type==='shield'}
function paintTimer(){$('secret-timer').textContent=Math.max(0,sec.left);const ring=document.querySelector('.timer-ring');ring.style.setProperty('--p',Math.max(0,sec.left)/secretSeconds());ring.classList.toggle('is-low',sec.left<=5)}
$('secret-reveal').onclick=()=>{paintChoice();paintTimer();step('choose');clearInterval(sec.timer);sec.timer=setInterval(()=>{sec.left--;paintTimer();if(sec.left<=0){clearInterval(sec.timer);install()}},1000)};
document.querySelectorAll('[data-device]').forEach(b=>b.onclick=()=>{sec.type=b.dataset.device;paintChoice()});
document.querySelectorAll('[data-sector]').forEach(b=>b.onclick=()=>{sec.sector=+b.dataset.sector;paintChoice()});
function summaryText(d){return d.type==='shield'?'방어막':`${DEVICE_NAME[d.type]} · ${SECTOR_NAME[d.sector]}`}
$('secret-next').onclick=()=>{const d={type:sec.type,sector:sec.sector};const p=$('secret-summary');p.replaceChildren();const ic=document.createElement('i');ic.className='ico ico-'+d.type;ic.setAttribute('aria-hidden','true');p.append(ic,document.createTextNode(summaryText(d)));step('confirm')};
$('secret-back').onclick=()=>{paintChoice();step('choose')};
$('secret-ok').onclick=()=>install();
function install(){clearInterval(sec.timer);const t=sec.teams[sec.k];sec.devices[t.id]={type:sec.type,sector:sec.type==='shield'?0:sec.sector};sec.k++;
 if(sec.k<sec.teams.length)return handoff();dlg.close();st.pending={seed:rint(),devices:sec.devices};sec=null;save();openRace()}


/* ── 3-2) 각자 폰으로 고르기 (인터넷·서버 없이) ──
 * 참가자 폰: 판 번호 + 팀 번호 + 고른 장치 → 숫자 4자리 코드.
 * 코드 = (선택값 + 무작위 덧칠) × 섞는 수 + 판·팀 열쇠  (10000으로 나눈 나머지).
 * 진행자 화면은 같은 판 번호·팀 번호로 거꾸로 풀어서 장치를 알아냄. 판·팀이 다르면 같은 선택도 전혀 다른 숫자가 나옴.
 * 잘못 친 번호는 대부분(약 93%) '다시 확인'으로 걸러짐. */
const PICKS=[['trap',0],['trap',1],['trap',2],['shortcut',0],['shortcut',1],['shortcut',2],['shield',0]];
const CODE_MUL=7919,CODE_INV=(()=>{for(let i=1;i<10000;i++)if(i*CODE_MUL%10000===1)return i})();
function codeSalt(key,no){return Math.floor(E.rng(key*977+no*131+7)()*10000)}
function makeCode(key,no,type,sector){const c=PICKS.findIndex(([t,s])=>t===type&&(t==='shield'||s===sector));const p=Math.floor(Math.random()*100)*7+c;
 return String((p*CODE_MUL+codeSalt(key,no))%10000).padStart(4,'0')}
function readCode(key,no,code){if(!/^\d{4}$/.test(code))return null;const x=((+code-codeSalt(key,no))%10000+10000)%10000,p=x*CODE_INV%10000;
 if(p>=700)return null;const [type,sector]=PICKS[p%7];return{type,sector}}

/* 진행자 쪽 */
const dlgCode=$('dlg-code');let pc=null; // {key, teams, devices:{id:{type,sector}}}
dlgCode.addEventListener('cancel',e=>e.preventDefault());
function startPhonePick(){let key;do key=10+Math.floor(Math.random()*90);while(st.lastCodeKey===key);st.lastCodeKey=key;save();
 pc={key,teams:raceTeams(),devices:{}};$('code-key').textContent=key;document.querySelectorAll('.code-key-inline').forEach(e=>e.textContent=key);
 const box=$('code-list');box.replaceChildren();
 pc.teams.forEach(t=>{const r=tpl('tpl-code-row');plate(r.querySelector('.plate'),t.no);r.querySelector('.code-name').textContent=st.mode==='tour'&&t.name!==`${t.no}팀`?`${t.no}팀 ${t.name}`:t.name;
  const inp=r.querySelector('input'),stt=r.querySelector('.code-st');inp.setAttribute('aria-label',`${t.no}팀 코드`);
  inp.oninput=()=>{inp.value=inp.value.replace(/\D/g,'').slice(0,4);const d=inp.value.length===4?readCode(key,t.no,inp.value):null;
   if(d){pc.devices[t.id]=d;r.dataset.state='ok';stt.textContent='✓ 받음';const all=[...box.querySelectorAll('input')],nx=all[all.indexOf(inp)+1];if(nx&&!nx.value)nx.focus()}
   else{delete pc.devices[t.id];r.dataset.state=inp.value.length===4?'bad':'';stt.textContent=inp.value.length===4?'다시 확인':''}
   paintCode()};
  box.append(r)});
 paintCode();if(!dlgCode.open)dlgCode.showModal();const f=box.querySelector('input');if(f)f.focus()}
function paintCode(){const n=Object.keys(pc.devices).length,N=pc.teams.length;$('code-progress').textContent=`${n} / ${N}팀`;
 $('code-go').textContent=n===N?'출발':n===0?'코드를 입력해 주세요':`출발 (${N-n}팀은 장치 없이)`;$('code-go').disabled=n===0}
$('code-cancel').onclick=()=>{dlgCode.close();pc=null};
$('code-go').onclick=()=>{if(!pc||!Object.keys(pc.devices).length)return;const devices={};pc.teams.forEach(t=>{const d=pc.devices[t.id];if(d)devices[t.id]={type:d.type,sector:d.type==='shield'?0:d.sector}});
 dlgCode.close();pc=null;st.pending={seed:rint(),devices};save();openRace()};
$('lobby-phone').onclick=()=>{hazardMode=false;startPhonePick()};

/* 참가자 쪽 */
const pk={key:'',no:0,type:'trap',sector:0};
function pickStep(name){['pick-who','pick-choose','pick-code'].forEach(id=>$(id).hidden=id!==name);window.scrollTo(0,0)}
function renderPick(){show('screen-pick');const box=$('pick-teams');box.replaceChildren();
 for(let i=1;i<=10;i++){const b=document.createElement('button');b.type='button';b.className='pick-team';b.setAttribute('aria-pressed',String(pk.no===i));b.setAttribute('aria-label',`${i}팀`);
  const pl=document.createElement('span');pl.className='plate';plate(pl,i);b.append(pl);b.onclick=()=>{pk.no=i;box.querySelectorAll('.pick-team').forEach((x,j)=>x.setAttribute('aria-pressed',String(j+1===i)));$('pick-err').hidden=true};box.append(b)}
 $('pick-key').value=pk.key;$('pick-err').hidden=true;pickStep('pick-who')}
function pickLine(){return`판 번호 ${pk.key} · ${pk.no}팀`}
function paintPick(){document.querySelectorAll('[data-pdevice]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.pdevice===pk.type)));document.querySelectorAll('[data-psector]').forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.psector===pk.sector)));$('pick-sector-field').hidden=pk.type==='shield'}
$('pick-key').oninput=()=>{$('pick-key').value=$('pick-key').value.replace(/\D/g,'').slice(0,2);$('pick-err').hidden=true};
$('pick-go').onclick=()=>{const k=$('pick-key').value;const err=!/^\d{2}$/.test(k)||+k<10?'판 번호 2자리를 넣어 주세요.':!pk.no?'우리 팀 번호를 눌러 주세요.':'';
 if(err){$('pick-err').textContent=err;$('pick-err').hidden=false;return}pk.key=k;pk.type='trap';pk.sector=0;$('pick-line').textContent=pickLine();paintPick();pickStep('pick-choose')};
document.querySelectorAll('[data-pdevice]').forEach(b=>b.onclick=()=>{pk.type=b.dataset.pdevice;paintPick()});
document.querySelectorAll('[data-psector]').forEach(b=>b.onclick=()=>{pk.sector=+b.dataset.psector;paintPick()});
$('pick-make').onclick=()=>{$('pick-codeval').textContent=makeCode(+pk.key,pk.no,pk.type,pk.sector);$('pick-code-line').textContent=pickLine();
 $('pick-mine').textContent='내 선택: '+summaryText({type:pk.type,sector:pk.sector});$('pick-mine').hidden=true;$('pick-peek').setAttribute('aria-pressed','false');$('pick-peek').textContent='내 선택 확인';pickStep('pick-code')};
$('pick-peek').onclick=()=>{const on=$('pick-mine').hidden;$('pick-mine').hidden=!on;$('pick-peek').setAttribute('aria-pressed',String(on));$('pick-peek').textContent=on?'선택 숨기기':'내 선택 확인'};
$('pick-who-back').onclick=()=>pickStep('pick-who');
$('pick-again').onclick=()=>{paintPick();pickStep('pick-choose')};
$('pick-next').onclick=()=>{pk.key='';renderPick();$('pick-key').focus()};
$('pick-home').onclick=()=>renderStart();
$('start-pick').onclick=()=>renderPick();

/* ── 4) 중계 화면 ── */
const raceR=R.createRenderer($('race-canvas'),{viewport:true});let S=null,teams=[],running=false,t0=0,pausedAt=0,lastUi=0,evIdx=0,recorded=false,wake=null,frameTimes=[],bannerQ=[],bannerUntil=0;
function raceView(){return{mode:running||(S&&S.done)?'race':'preview',sectors:false,showBadges:true,selectedTile:-1,teamIdx:teamIdx(teams),cam:fx.cam,finalZone:APP.fxFinal!==false}}

/* ── 연출 감독 ──
 * 경주 계산(엔진)은 그대로 두고, 보여주는 시간 흐름과 카메라만 조절합니다. 그래서 승률 균형에 영향이 없어요.
 * - 출발: 카메라가 출발선에서 전체 화면으로 빠짐
 * - 결승 구간(7·8·9번 조각): 1·2·3위가 모두 들어오면 '결승 구간!' 팝업 → 세 대를 따라가며 확대·슬로모션·기울어진 중계 화면
 * - 순위가 바뀔 만한 미사일·번개: 잠깐 시간이 멈추듯 느려지고 카메라가 맞는 차로 당겨지며 화면이 흔들림 */
const finalP=()=>S?(S.tiles.length-3)/S.tiles.length:6/9; // 마지막 3조각 = 결승 구간
const CW=()=>raceR.W||760,CH=()=>raceR.H||650,ZS=()=>Math.min(1.6,Math.max(1,CW()/760)); // ZS: 지도가 클수록 확대 배율도 키움
const fx={cam:{x:380,y:325,z:1},simClock:0,lastNow:0,introUntil:0,finalOn:false,finalDone:false,impact:null,lastImpact:-1e9,idx:0,shake:0};
function fxReset(){Object.assign(fx,{cam:{x:CW()/2,y:S?E.carPos(S,S.cars[0]).y:0,z:1},simClock:0,lastNow:0,introUntil:0,finalOn:false,finalDone:false,impact:null,lastImpact:-1e9,idx:0,shake:0});$('race-canvas').parentElement.classList.remove('is-tilt');}
function fxLayer(){let fl=$('fx-flash'),pop=$('fx-pop');if(!fl){fl=document.createElement('div');fl.id='fx-flash';fl.className='fx-flash';pop=document.createElement('div');pop.id='fx-pop';pop.className='fx-pop';pop.setAttribute('role','status');const host=$('race-canvas').parentElement;host.append(fl,pop)}return{fl,pop}}
function flash(kind){const {fl}=fxLayer();fl.dataset.kind=kind;fl.classList.remove('is-on');void fl.offsetWidth;fl.classList.add('is-on')}
function popup(big,small,kind){const {pop}=fxLayer();pop.replaceChildren();const b=document.createElement('b');b.textContent=big;pop.append(b);if(small){const s2=document.createElement('small');s2.textContent=small;pop.append(s2)}pop.dataset.kind=kind||'';pop.classList.remove('is-on');void pop.offsetWidth;pop.classList.add('is-on')}
function timeScale(now){let k=1;if(fx.finalOn&&!fx.finalDone)k=Math.min(k,Math.max(.1,(APP.finalSlow||50)/100));if(fx.impact){const age=now-fx.impact.at;if(age<650)k=Math.min(k,.12);else if(age<1300)k=Math.min(k,.12+(age-650)/650*.88)}return k}
function ease(a,b,f){return a+(b-a)*f}
// 기본 카메라: 지도 폭에 맞추고, 선두 무리를 따라 위아래로 부드럽게 스크롤
function followTarget(){const order=E.standings(S).filter(c=>c.time===null),src=order.length?order:E.standings(S);const lead=E.carPos(S,src[0]),mid=E.carPos(S,src[Math.min(2,src.length-1)]);
 return{x:CW()/2,y:lead.y*.65+mid.y*.35+40,z:1}}
function directCamera(now){let target=followTarget();
 if(now<fx.introUntil){const a=E.carPos(S,S.cars[0]),f=1-(fx.introUntil-now)/1600,e=f*f*(3-2*f);target={x:ease(a.x+60,target.x,e),y:ease(a.y,target.y,e),z:ease(2.4*ZS(),1,e)};Object.assign(fx.cam,target);return}
 if(fx.finalOn&&!fx.finalDone){const top=E.standings(S).slice(0,3);const ps=top.map(c=>E.carPos(S,c));let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;for(const p of ps){x0=Math.min(x0,p.x);x1=Math.max(x1,p.x);y0=Math.min(y0,p.y);y1=Math.max(y1,p.y)}
  target={x:(x0+x1)/2+30,y:(y0+y1)/2,z:Math.max(1.35*ZS(),Math.min(2.3*ZS(),Math.min(CW()/(x1-x0+300),(raceR.VH||CH())/(y1-y0+240))))}}
 if(fx.impact&&now-fx.impact.at<1300){const c=S.cars[fx.impact.b];if(c){const p=E.carPos(S,c),age=now-fx.impact.at,f=age<300?age/300:age<900?1:1-(age-900)/400;target.x=ease(target.x,p.x,f*.8);target.y=ease(target.y,p.y,f*.8);target.z=Math.max(target.z,ease(target.z,2.1*ZS(),f))}}
 const k=fx.finalOn&&!fx.finalDone?.09:.06;fx.cam.x+=(target.x-fx.cam.x)*k;fx.cam.y+=(target.y-fx.cam.y)*k;fx.cam.z+=(target.z-fx.cam.z)*k;
 if(fx.shake>0){fx.cam.sx=(Math.random()-.5)*fx.shake;fx.cam.sy=(Math.random()-.5)*fx.shake;fx.shake*=.86;if(fx.shake<.3)fx.shake=0}else{fx.cam.sx=fx.cam.sy=0}}
function directEvents(now){const order=E.standings(S),rank=new Map(order.map((c,i)=>[c.idx,i+1]));
 while(fx.idx<S.events.length){const e=S.events[fx.idx++];
  // 하이라이트는 중반 이후, 1위가 맞았고 2위가 바짝 붙어 있어 1·2위가 바뀔 만할 때만
  if(APP.fxImpact!==false&&(e.k==='hit'||e.k==='bolt')){const lead=order[0],second=order[1],rb=rank.get(e.b);
   const close=second&&lead&&lead.time===null&&(lead.p-second.p)<.035;
   if(rb===1&&close&&lead.p>=.5&&now-fx.lastImpact>4000){fx.impact={at:now,b:e.b,k:e.k};fx.lastImpact=now;fx.shake=e.k==='bolt'?14:9;flash(e.k);popup(e.k==='bolt'?'번개 강타!':'미사일 명중!',`선두 ${nameOf(e.b)} 흔들 · ${nameOf(second.idx)} 역전 기회!`,e.k)}}}
 if(fx.impact&&now-fx.impact.at>1400)fx.impact=null;
 // 결승 구간: 1·2·3위가 모두 7번 조각 이후에 들어오면 시작
 if(APP.fxFinal!==false&&!fx.finalOn){const top=order.slice(0,Math.min(3,order.length));if(top.length&&top.every(c=>c.p>=finalP()||c.time!==null)){fx.finalOn=true;popup('결승 구간!','1·2·3위 진입 · 슬로모션','final');flash('final');if(APP.fx3d!==false)$('race-canvas').parentElement.classList.add('is-tilt')}}
 if(fx.finalOn&&!fx.finalDone){const top=order.slice(0,Math.min(3,order.length));if(top.every(c=>c.time!==null)){fx.finalDone=true;$('race-canvas').parentElement.classList.remove('is-tilt');popup(`${nameOf(order[0].idx)} 우승!`,'','finish')}}}
function nameOf(i){const t=teams[i];return t?t.name:'?'}
function openRace(){teams=raceTeams();const p=st.pending;
 S=E.createRace({seed:p.seed,tiles:st.tiles.slice(),locked:st.locked.slice(),chaos:st.settings.chaos,battle:st.settings.battle,bolt:st.settings.bolt!==false,hazards:(st.hazards||[]).slice(),racers:teams.map(t=>({id:t.id,name:t.name,device:st.settings.devices===false?null:(p.devices[t.id]||null)}))});
 running=false;evIdx=0;recorded=false;bannerQ=[];bannerUntil=0;frameTimes=[];fxReset();show('screen-race');raceR.resize();
 $('race-stage').textContent=stageLabel()+(p.practice?' · 연습 주행':'');$('race-timer').textContent='0.0';$('race-live').hidden=true;$('race-to-result').hidden=true;
 $('race-start').hidden=false;$('race-start').parentElement.hidden=false;$('race-countdown').hidden=true;$('race-banner').classList.remove('is-show');
 tower();raceR.drawFrame(S,raceView())}
$('race-start').onclick=()=>{$('race-start').hidden=true;$('race-start').parentElement.hidden=true;const cd=$('race-countdown');cd.hidden=false;let n=3;$('race-count').textContent=n;
 const iv=setInterval(()=>{n--;if(n>0){$('race-count').textContent=n;return}clearInterval(iv);cd.hidden=true;go()},700/SPEED)};
async function lockScreen(){try{if(navigator.wakeLock)wake=await navigator.wakeLock.request('screen')}catch(e){wake=null}}
function go(){running=true;fxReset();fx.lastNow=performance.now();if(APP.fxIntro!==false)fx.introUntil=fx.lastNow+1600;raceR.setZoomHint(2.4*ZS());$('race-live').hidden=false;lockScreen();requestAnimationFrame(frame)}
document.addEventListener('visibilitychange',()=>{if(!running)return;if(!document.hidden){fx.lastNow=performance.now();lockScreen();requestAnimationFrame(frame)}});
function frame(now){if(!running||document.hidden)return;const a=performance.now();
 const realDt=Math.min(.1,Math.max(0,(now-fx.lastNow)/1000));fx.lastNow=now;
 directEvents(now);fx.simClock+=realDt*SPEED*timeScale(now);E.advanceTo(S,fx.simClock,12*SPEED);directCamera(now);raceR.drawFrame(S,raceView());
 if(frameTimes.length<90){frameTimes.push(now);if(frameTimes.length===90){const d=(frameTimes[89]-frameTimes[30])/59;if(d>30)raceR.setQuality(1)}}
 if(now-lastUi>100){lastUi=now;tower();$('race-timer').textContent=S.t.toFixed(1)}
 pumpEvents(now);
 if(S.done)return finishRace();requestAnimationFrame(frame)}
// 순위 타워: 팀마다 줄 하나를 계속 쓰고, 순서가 바뀌면 1초에 한 번만 부드럽게 미끄러지며 자리 이동.
// 왼쪽 등수 숫자(1·2·3…)는 반대로 움직여 제자리에 고정되어 보이게 함
let towerRows=null,towerOrderAt=0,towerOrder=[];
const reduceMotion=typeof matchMedia!=='undefined'&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function tower(){const list=$('race-tower'),started=S.t>0,now=performance.now();list.parentElement.classList.toggle('no-gauge',!S.cfg.battle);
 if(!towerRows||towerRows.length!==S.n||towerRows.S!==S){towerRows=S.cars.map(()=>tpl('tpl-tower-row'));towerRows.S=S;towerOrder=[];list.replaceChildren()}
 const fresh=E.standings(S).map(c=>c.idx),changed=fresh.join()!==towerOrder.join();
 if(changed&&(now-towerOrderAt>1000||!towerOrder.length||S.done)){
  const before=new Map(towerRows.map((r,i)=>[i,r.isConnected?r.getBoundingClientRect().top:null]));
  const oldPos=new Map(towerOrder.map((x,i)=>[x,i]));towerOrder=fresh;towerOrderAt=now;towerOrder.forEach(i=>list.append(towerRows[i]));
  if(oldPos.size&&S.t>5)towerOrder.forEach((idx,i)=>{const o=oldPos.get(idx);if(o===undefined||o===i)return;const r=towerRows[idx];r.dataset.move=o>i?'up':'down';clearTimeout(r._mv);r._mv=setTimeout(()=>{delete r.dataset.move},1600)});
  if(!reduceMotion)towerOrder.forEach(i=>{const r=towerRows[i],b=before.get(i);if(b===null)return;const d=b-r.getBoundingClientRect().top;if(!d)return;const pz=r.querySelector('.tw-pos');r.style.transition=pz.style.transition='none';r.style.transform=`translateY(${d}px)`;pz.style.transform=`translateY(${-d}px)`;r.getBoundingClientRect();requestAnimationFrame(()=>{const ease='transform .6s cubic-bezier(.2,.7,.2,1)';r.style.transition=pz.style.transition=ease;r.style.transform=pz.style.transform=''})})}
 towerOrder.forEach((idx,i)=>{const row=towerRows[idx],c=S.cars[idx],t=teams[idx];row.querySelector('.tw-pos').textContent=i+1;plate(row.querySelector('.plate'),t.no);row.querySelector('.tw-name').textContent=t.name;
  const slow=c.time===null&&c.slow>S.t,hit=c.time===null&&c.spin>S.t;row.className='tw-row'+(started&&i===0?' is-lead':'')+(slow?' is-slow':'')+(hit?' is-hit':'')+(c.time!==null?' is-done':'');
  row.querySelector('.tw-stat').textContent=c.time!==null?c.time.toFixed(2)+'초':hit?'피격':slow?'감속':started?Math.floor(c.p*100)+'%':'';
  const g=row.querySelector('.gauge');g.style.setProperty('--g',c.time===null?c.gauge.toFixed(2):0);g.classList.toggle('is-full',c.time===null&&c.gauge>=1)})}
function eventBanner(e){const A=nameOf(e.a),B=nameOf(e.b);switch(e.k){
 case'trap':return[e.wild?`${A}의 트랩이 엉뚱하게 ${B}를 붙잡았어요!`:`${A} 트랩 → ${B} 감속`,'trap',2];
 case'shortcut':return[`${A} 비밀 지름길! 앞으로 점프`,'shortcut',2];
 case'deadend':return[`${A}의 지름길은 막다른 길!`,'shortcut',2];
 case'block':return[`${A} 방어막이 ${e.by==='missile'?'미사일':'트랩'}을 막았어요`,'shield',2];
 case'hit':return[`${A} 미사일 명중 → ${B} 스핀`,'hit',1];
 case'bolt':return[`꼴찌 ${A}의 번개! 선두 ${B} 정지`,'bolt',2];
 case'remix':return[`${e.tile+1}번 조각이 ${E.shapeNames[e.v]}(으)로 바뀌었어요`,'remix',0];
 case'hazard':return[`${A} 맵 트랩에 걸림!`,'trap',1];
 case'finish':return e.place===1?[`${A} 1위로 결승선 통과!`,'finish',3]:null;
 default:return null}}
function pumpEvents(now){while(evIdx<S.events.length){const b=eventBanner(S.events[evIdx++]);if(b){bannerQ.push(b);if(bannerQ.length>3){const low=bannerQ.reduce((m,x,i)=>x[2]<bannerQ[m][2]?i:m,0);bannerQ.splice(low,1)}}}
 if(now>=bannerUntil&&bannerQ.length){const [text,kind]=bannerQ.shift();$('race-banner-text').textContent=text;const el=$('race-banner');el.dataset.kind=kind;el.classList.add('is-show');bannerUntil=now+(bannerQ.length?1600:2500)}
 else if(now>=bannerUntil)$('race-banner').classList.remove('is-show')}
function finishRace(){running=false;fx.cam={x:CW()/2,y:E.carPos(S,E.standings(S)[0]).y,z:1};$('race-canvas').parentElement.classList.remove('is-tilt');tower();$('race-timer').textContent=S.t.toFixed(1);$('race-live').hidden=true;$('race-to-result').hidden=false;raceR.drawFrame(S,raceView());
 try{wake&&wake.release()}catch(e){}wake=null;
 if(!recorded){recorded=true;if(st.mode==='tour'&&!st.pending.practice){TR.record(st.T,E.standings(S).map(c=>c.id),TR.statsFromRace(S))}lastRace={S,teams,practice:!!st.pending.practice,label:$('race-stage').textContent,tourResult:st.mode==='tour'&&!st.pending.practice?st.T.results[st.T.results.length-1]:null};st.pending=null;save()}
 setTimeout(()=>{if(!$('screen-race').hidden)$('race-banner').classList.remove('is-show')},3000)}
$('race-to-result').onclick=()=>renderResult();

/* ── 5) 결과 + 범인 공개 ── */
let lastRace=null;
function recapCard(r){const c=tpl('tpl-recap'),own=lastRace.teams[r.owner],nm=i=>lastRace.teams[i]?lastRace.teams[i].name:'?';c.dataset.type=r.type;c.querySelector('.ico').classList.add('ico-'+r.type);plate(c.querySelector('.plate'),own.no);c.querySelector('.rc-name').textContent=own.name;
 c.querySelector('.rc-what').textContent=r.type==='shield'?'방어막':`${DEVICE_NAME[r.type]} · ${SECTOR_NAME[r.sector]||''}`;
 let text='',good='none',swing='';const rk=(a,b)=>a&&b?`${a}위 → ${b}위`:'';
 if(r.type==='trap'){if(r.result==='hit'||r.result==='wild'){text=`${r.wild?'엉뚱하게 ':''}${nm(r.victim)}가 걸려 감속 · 내 차는 가속`;good='good';swing=rk(r.rankBefore,r.victimRank)?`${nm(r.victim)} ${rk(r.rankBefore,r.victimRank)}`:''}
  else if(r.result==='blocked'){text=`${nm(r.victim)}의 방어막에 막힘`;good='bad'}else text='아무도 걸리지 않음'}
 else if(r.type==='shortcut'){if(r.result==='jump'){text='점프 성공!';good='good';swing=rk(r.rankBefore,r.rankAfter)}else if(r.result==='deadend'){text='막다른 길! 잠깐 멈춤';good='bad';swing=r.rankBefore&&r.ownerRank?`${r.rankBefore}위 → 최종 ${r.ownerRank}위`:''}else text='발동하기 전에 끝남'}
 else if(r.type==='shield'){if(r.result==='blocked'){text=`${r.attacker!==undefined&&r.attacker!==null?nm(r.attacker)+'의 ':''}트랩을 막음`;good='good'}else text='트랩을 만나지 않음'}
 c.dataset.result=good;c.querySelector('.rc-result').textContent=text;c.querySelector('.rc-swing').textContent=swing;return c}
function renderResult(){if(!lastRace)return renderLobby();show('screen-result');const {S:RS,teams:tm}=lastRace,tr=lastRace.tourResult;
 $('result-stage').textContent=lastRace.label+' 결과';const list=$('result-rank');list.replaceChildren();
 E.standings(RS).forEach((c,i)=>{const r=tpl('tpl-result-row'),t=tm[c.idx];r.querySelector('.rs-pos').textContent=i+1;plate(r.querySelector('.plate'),t.no);r.querySelector('.rs-name').textContent=t.name;r.querySelector('.rs-time').textContent=c.time!==null?c.time.toFixed(2)+'초':'';r.querySelector('.rs-pts').textContent=tr?'+'+(tr.points[t.id]||0):'';list.append(r)});
 const box=$('result-recap');box.replaceChildren();const recap=(RS.recap||[]).slice().sort((a,b)=>(a.result==='unused')-(b.result==='unused'));
 for(const r of recap)box.append(recapCard(r));
 // 맵 트랩 결과: 트랩마다 누가 걸렸는지
 (RS.hazards||[]).forEach((z,h)=>{const c=tpl('tpl-recap'),who=RS.events.filter(e=>e.k==='hazard'&&e.h===h).map(e=>tm[e.a]?tm[e.a].name:'?'),sec=E.hazardSector(z.p);
  c.dataset.type='hazard';c.dataset.result=who.length?'bad':'none';c.querySelector('.ico').classList.add('ico-hazard');c.querySelector('.plate').hidden=true;
  c.querySelector('.rc-name').textContent=`맵 트랩 ${h+1}`;c.querySelector('.rc-what').textContent=`${['초반','중반','후반'][sec]} · 확률 ${Math.round(E.HAZARD.chance[sec]*100)}%`;
  c.querySelector('.rc-result').textContent=who.length?`${who.join(', ')} 걸림`:'아무도 걸리지 않음';c.querySelector('.rc-swing').textContent=`${z.hits}/${z.hits+z.miss}대`;box.append(c)});
 if(!box.children.length){const p=document.createElement('p');p.className='muted';p.textContent='이번 판은 비밀 장치도 맵 트랩도 없었어요.';box.append(p)}
 const tour=st&&st.mode==='tour'&&!lastRace.practice;$('result-again').hidden=!(st&&st.mode==='quick');$('result-board').hidden=!(st&&st.mode==='tour');
 $('result-next').textContent=nextLabel()}
function nextLabel(){if(!st||st.mode==='quick')return'트랙으로';const T=st.T;if(T.stage==='done')return'시상식';const race=TR.current(T),prev=T.results[T.results.length-1];if(race.stage==='final'&&(!prev||prev.stage==='heat'))return'결승으로';return'다음 판'}
function goNext(){if(!st)return renderStart();if(st.mode==='quick')return renderLobby();const T=st.T;if(T.stage==='done')return renderAward();const race=TR.current(T),prev=T.results[T.results.length-1];
 if(race.stage==='final'&&race.round===1&&prev&&prev.stage==='heat')return renderFinalIntro();renderLobby()}
$('result-next').onclick=goNext;$('result-again').onclick=()=>renderLobby();$('result-board').onclick=()=>renderBoard('screen-result');

/* ── 6) 점수판 ── */
let boardBack='screen-lobby';
function renderBoard(from){boardBack=from||'screen-lobby';show('screen-board');const T=st.T;
 const prog=$('board-progress');prog.replaceChildren();
 const addProg=(name,stage,group,of)=>{const p=tpl('tpl-group-progress');p.querySelector('.gp-name').textContent=name;const done=T.results.filter(r=>r.stage===stage&&(group<0||r.group===group)).length,cur=TR.current(T);
  for(let i=0;i<of;i++){const d=document.createElement('i');if(i<done)d.className='is-done';else if(i===done&&cur&&cur.stage===stage&&(group<0||cur.group===group))d.className='is-next';p.querySelector('.gp-dots').append(d)}p.querySelector('.gp-text').textContent=`${done}/${of}판`;prog.append(p)};
 T.groups.forEach((g,gi)=>addProg(TR.groupLabel(T,gi)||'예선','heat',gi,T.heats));if(T.finalists)addProg('결승','final',-1,T.finals);
 const C=Math.max(T.heats,T.finalists?T.finals:0),head=$('board-head');head.replaceChildren();const th=(t)=>{const e=document.createElement('th');e.scope='col';e.textContent=t;head.append(e)};th('팀');for(let i=1;i<=C;i++)th(i+'판');th('합계');
 const body=$('board-body');body.replaceChildren();
 const section=(title)=>{const tr=document.createElement('tr');tr.className='grp';const h=document.createElement('th');h.colSpan=C+2;h.scope='colgroup';h.textContent=title;tr.append(h);body.append(tr)};
 const rows=(stage,group,cut,mark)=>{const list=TR.standings(T,stage,group);list.forEach((row,k)=>{const tr=tpl('tpl-board-row'),t=TR.teamOf(T,row.id);plate(tr.querySelector('.plate'),t.no);tr.querySelector('.bt-name').textContent=t.name;
  const total=tr.querySelector('.cell-total');const races=T.results.filter(r=>r.stage===stage&&(group<0||group===undefined||r.group===group));
  for(let i=0;i<C;i++){const td=document.createElement('td');td.className='cell-race';const r=races[i];if(r&&r.order.includes(row.id)){const p=r.order.indexOf(row.id)+1;if(p===1)td.classList.add('is-win');td.textContent=p;const s=document.createElement('small');s.textContent='위';td.append(s)}else td.textContent='—';tr.insertBefore(td,total)}
  total.textContent=row.total;if(mark==='final'&&T.finalists&&T.finalists.includes(row.id))tr.classList.add('is-final');else if(mark==='final'&&T.finalists)tr.classList.add('is-out');else if(cut&&k<cut)tr.classList.add('is-final');if(cut&&k===cut-1&&list.length>cut)tr.classList.add('cut-line');body.append(tr)})};
 const fin=T.teams.length>=5&&T.finals>0,per=T.groups.length>1?4:Math.min(4,T.teams.length);
 if(T.finalists&&T.results.some(r=>r.stage==='final')){section('결승 (결승 점수만 합산)');rows('final',-1,0)}
 T.groups.forEach((g,gi)=>{if(T.groups.length>1)section(`${TR.groupLabel(T,gi)} 예선`);else if(T.finalists&&T.results.some(r=>r.stage==='final'))section('예선');rows('heat',T.groups.length>1?gi:-1,fin?per:0,T.finalists?'final':'')});
 $('board-note').textContent=fin?`${T.groups.length>1?'각 조 상위 4팀':'누적 상위 '+per+'팀'} 결승 진출 · 동점이면 1위 횟수, 그다음 최근 판 순위`:'누적 점수로 최종 순위 · 동점이면 1위 횟수, 그다음 최근 판 순위';
 $('board-next').textContent=T.stage==='done'?'시상식':nextLabel()==='결승으로'?'결승으로':'다음 판으로'}
$('board-back').onclick=()=>{if(boardBack==='screen-result'&&lastRace)renderResult();else renderLobby()};
$('board-next').onclick=()=>goNext();

/* ── 7) 결승·시상 ── */
function renderFinalIntro(){show('screen-final');$('screen-final').dataset.phase='intro';const T=st.T,box=$('final-teams');box.replaceChildren();
 for(const id of T.finalists){const t=TR.teamOf(T,id),e=tpl('tpl-entry');plate(e.querySelector('.plate'),t.no);e.querySelector('.entry-name').textContent=t.name;box.append(e)}
 document.querySelector('.final-sub').textContent=`예선 상위 ${T.finalists.length}팀 · ${T.finals}판 합산`}
$('final-go').onclick=()=>renderLobby();
function renderAward(){show('screen-final');$('screen-final').dataset.phase='award';const T=st.T,rank=TR.finalRanking(T),useFinal=T.finalists&&T.results.some(r=>r.stage==='final');
 [1,2,3].forEach(p=>{const el=$('podium-'+p),r=rank[p-1];el.hidden=!r;if(!r)return;const t=TR.teamOf(T,r.id);plate(el.querySelector('.plate'),t.no);el.querySelector('.pd-name').textContent=t.name;el.querySelector('.pd-score').textContent=`${r.total}점${useFinal&&p<=T.finalists.length?' (결승)':''}`});
 const sum={};for(const t of T.teams)sum[t.id]={landed:0,trapHits:0,deadends:0,hitTaken:0,blocks:0,bolts:0};for(const r of T.results)for(const id in r.stats){for(const k in sum[id]||{})sum[id][k]+=r.stats[id][k]||0}
 const award=(elId,score,why)=>{const el=$(elId);let best=null;for(const t of T.teams){const v=score(sum[t.id]);if(v>0&&(!best||v>best.v))best={t,v}}el.hidden=!best;if(!best)return;plate(el.querySelector('.plate'),best.t.no);el.querySelector('.aw-name').textContent=best.t.name;el.querySelector('.aw-why').textContent=why(sum[best.t.id])};
 award('award-sniper',s=>s.landed,s=>`미사일 명중 ${s.landed}회`);
 award('award-trap',s=>s.trapHits,s=>`트랩으로 ${s.trapHits}번 붙잡음`);
 award('award-unlucky',s=>s.deadends*2+s.hitTaken,s=>[s.deadends?`막다른 길 ${s.deadends}번`:'',s.hitTaken?`미사일 ${s.hitTaken}번 맞음`:''].filter(Boolean).join(' · '))}
$('final-home').onclick=()=>{store.clear();st=null;renderStart()};

/* ── 시작 ── */
if(new URLSearchParams(location.search).has('pick'))renderPick();else{renderStart();if(window.SGIntro&&!new URLSearchParams(location.search).has('nointro'))SGIntro.play()}
window.__sg={readCode,makeCode,get st(){return st},get S(){return S},get fx(){return fx}};
/* 휴대폰 '뒤로가기' 버튼 (앱 버전에서 호출). 처리했으면 true, 앱을 닫아도 되면 false */
window.SGBack=function(){try{
 const typing=isTyping();hideKeyboard();
 const intro=$('sg-intro');if(intro&&!intro.hidden){SGIntro.skip();return true}
 if($('dlg-custom').open){$('dlg-custom').close();return true}
 if(typing&&!dlg.open&&!dlgCode.open)return true; // 화면에서 이름 입력 중이었으면 키보드만 내림
 if(dlg.open)return true; // 비밀 장치 고르는 중에는 무시
 if(dlgCode.open){$('code-cancel').click();return true}
 const vis=[...document.querySelectorAll('.screen')].find(x=>!x.hidden);if(!vis)return false;
 switch(vis.id){
  case'screen-start':return false;
  case'screen-pick':if(!$('pick-who').hidden){renderStart();return true}pickStep('pick-who');return true;
  case'screen-lobby':hazardMode=false;save();renderStart();return true;
  case'screen-race':if(running)return true;if(S&&S.done){renderResult();return true}renderLobby();return true;
  case'screen-result':renderLobby();return true;
  case'screen-board':$('board-back').click();return true;
  case'screen-final':renderStart();return true}
 return false}catch(e){return false}};
})();
