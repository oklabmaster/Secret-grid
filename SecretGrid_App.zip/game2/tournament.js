/* SECRET GRID 행사판 — 대회 진행 로직 (실장)
 * 화면과 무관한 순수 계산: 조 편성, 경기 순서, 순위 점수, 동점 처리, 결승 진출, 특별상.
 * 상태는 JSON 하나라 localStorage에 그대로 저장/복구할 수 있습니다.
 */
(function(G){
'use strict';
// 경주 인원별 순위 점수 (보드게임 마스터 안)
function pointsTable(size,final){
 if(final)return[12,9,7,5,4,3,2,1,0,0].slice(0,size);
 if(size<=5)return[10,7,5,3,1].slice(0,size);
 return[12,9,7,5,4,3,2,1,0,0].slice(0,size)}

/* opts: {teams:[이름...] (2~10), heats: 조별 예선 판 수(기본 3), finals: 결승 판 수(기본 2, 0이면 결승 없음)} */
function create(opts){const names=opts.teams.map((n,i)=>String(n||'').trim().slice(0,10)||`${i+1}팀`);const N=names.length;
 if(N<2||N>10)throw new Error('팀은 2~10팀');
 const teams=names.map((name,i)=>({id:'t'+(i+1),no:i+1,name}));
 const split=N>8;const groups=split?[teams.slice(0,Math.ceil(N/2)).map(t=>t.id),teams.slice(Math.ceil(N/2)).map(t=>t.id)]:[teams.map(t=>t.id)];
 const heats=Math.max(1,Math.min(6,opts.heats|0||3)),finals=Math.max(0,Math.min(4,opts.finals===undefined?2:opts.finals|0));
 // 예선 순서: 조를 번갈아가며
 const schedule=[];for(let h=0;h<heats;h++)groups.forEach((g,gi)=>schedule.push({stage:'heat',group:gi,round:h+1,of:heats,teams:g.slice()}));
 const pts=a=>Array.isArray(a)&&a.length?a.map(x=>Math.max(0,Math.round(+x)||0)):null;
 return{v:1,createdAt:Date.now(),teams,groups,heats,finals,schedule,results:[],finalists:null,stage:'heat',pointsHeat:pts(opts.pointsHeat),pointsFinal:pts(opts.pointsFinal),finalPer:Math.max(1,Math.min(8,opts.finalPer|0||4))}}
// 사용자 지정 점수표가 있으면 그것을, 없으면 기본 점수표를 씀 (모자라는 순위는 0점)
function tableFor(T,size,final){const c=final?T.pointsFinal:T.pointsHeat;if(!c)return pointsTable(size,final);return Array.from({length:size},(_,i)=>c[i]||0)}

function teamOf(T,id){return T.teams.find(t=>t.id===id)}
function groupLabel(T,gi){return T.groups.length>1?['A조','B조'][gi]:''}
function current(T){return T.schedule[T.results.length]||null}
function label(T,race){if(!race)return'';if(race.stage==='final')return`결승 ${race.round}/${race.of}판`;const g=groupLabel(T,race.group);return`예선 ${g?g+' ':''}${race.round}/${race.of}판`}

/* 한 판 결과 기록. order: 순위순 팀 id 배열, stats: {팀id:{landed,trapHits,deadends,blocks,bolts,hitTaken}} */
function record(T,order,stats){const race=current(T);if(!race)throw new Error('남은 경기가 없어요');
 const final=race.stage==='final',table=tableFor(T,order.length,final);
 T.results.push({stage:race.stage,group:race.group,round:race.round,order:order.slice(),points:Object.fromEntries(order.map((id,i)=>[id,table[i]||0])),stats:stats||{}});
 // 예선이 모두 끝났으면 결승 편성
 if(T.results.length===T.schedule.length&&T.stage==='heat'){
  if(T.finals>0&&T.teams.length>=5){const fp=T.finalPer||4,per=T.groups.length>1?Math.min(fp,...T.groups.map(g=>g.length)):Math.min(fp,T.teams.length-1); // 조가 둘이면 조당, 하나면 전체에서
   T.finalists=T.groups.flatMap((g,gi)=>standings(T,'heat',gi).slice(0,per).map(r=>r.id));
   if(T.finalists.length>=2){for(let r=0;r<T.finals;r++)T.schedule.push({stage:'final',group:-1,round:r+1,of:T.finals,teams:T.finalists.slice()});T.stage='final'}else T.stage='done'}
  else T.stage='done'}
 else if(T.results.length===T.schedule.length)T.stage='done';
 return T}

/* 순위표: 합계 → 1위 횟수 → 마지막 판 순위 → 팀 번호 */
function standings(T,stage,group){const rows=new Map();
 const ids=group===undefined||group<0?(stage==='final'&&T.finalists?T.finalists:T.teams.map(t=>t.id)):T.groups[group];
 for(const id of ids){const t=teamOf(T,id);rows.set(id,{id,no:t.no,name:t.name,total:0,wins:0,places:[],lastPlace:99})}
 for(const r of T.results){if(r.stage!==stage)continue;r.order.forEach((id,i)=>{const row=rows.get(id);if(!row)return;row.total+=r.points[id]||0;if(i===0)row.wins++;row.places.push(i+1);row.lastPlace=i+1})}
 return[...rows.values()].sort((a,b)=>b.total-a.total||b.wins-a.wins||a.lastPlace-b.lastPlace||a.no-b.no)}

/* 최종 순위: 결승이 있으면 결승 순위 → 나머지는 예선 합계 */
function finalRanking(T){if(T.finalists&&T.results.some(r=>r.stage==='final')){const fin=standings(T,'final'),rest=standings(T,'heat').filter(r=>!T.finalists.includes(r.id));return fin.concat(rest)}return standings(T,'heat')}

/* 특별상: 대회 전체 누적 */
function awards(T){const sum={};for(const t of T.teams)sum[t.id]={landed:0,trapHits:0,deadends:0,hitTaken:0,blocks:0,bolts:0};
 for(const r of T.results)for(const id in r.stats){const s=r.stats[id],a=sum[id];if(!a)continue;for(const k in a)a[k]+=s[k]||0}
 const best=(key,label,unit)=>{let top=null;for(const t of T.teams){const v=sum[t.id][key];if(v>0&&(!top||v>top.v))top={id:t.id,name:t.name,v}}return top?{key,label,team:top.name,id:top.id,value:top.v,unit}:null};
 return[best('landed','저격수상','미사일 명중'),best('trapHits','트랩 마스터','트랩 적중'),best('deadends','불운상','막다른 길'),best('blocks','철벽상','방어막 성공'),best('bolts','번개 역전상','번개 적중')].filter(Boolean)}

/* 엔진 경주 결과(S)에서 팀별 통계 뽑기. racers[k].id = 팀 id */
function statsFromRace(S){const st={};for(const c of S.cars)st[c.id]={landed:c.landed||0,trapHits:0,deadends:0,hitTaken:c.hits||0,blocks:0,bolts:0};
 const idOf=i=>S.cars[i]&&S.cars[i].id;
 for(const e of S.events){if(e.k==='trap'&&idOf(e.a)&&idOf(e.b)!==undefined)st[idOf(e.a)].trapHits++;if(e.k==='deadend'&&idOf(e.a))st[idOf(e.a)].deadends++;if(e.k==='block'&&idOf(e.a))st[idOf(e.a)].blocks++;if(e.k==='bolt'&&idOf(e.a))st[idOf(e.a)].bolts++}
 return st}

const api={pointsTable,create,current,label,record,standings,finalRanking,awards,statsFromRace,teamOf,groupLabel};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else G.SGTournament=api;
})(typeof globalThis!=='undefined'?globalThis:this);
