package com.secretgrid.game;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.view.inputmethod.InputMethodManager;
import android.window.OnBackInvokedDispatcher;

import androidx.webkit.WebViewAssetLoader;

/**
 * SECRET GRID 앱: 앱 안(assets/www)에 들어 있는 게임 화면을 그대로 띄웁니다.
 * - 인터넷 없이 동작, 진행 상황은 기기에 저장(localStorage)
 * - 경주 중 화면 꺼짐 방지
 * - 뒤로가기 버튼은 게임 화면 흐름을 따름 (첫 화면에서 누르면 앱 종료)
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";
    private WebView web;
    private FrameLayout box;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0E1822")); // 인트로와 같은 색 (앱 켤 때 번쩍임 방지)
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100); // 기기 글자 크기 설정 때문에 화면이 깨지지 않게
        s.setUserAgentString(s.getUserAgentString() + " SecretGridApp/1.0");

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !HOST.equals(u.getHost()); // 바깥 주소로는 이동하지 않음
            }
        });

        // 안드로이드 15+ 화면 가장자리까지 그리기: 상태바·홈바(내비게이션바)·키보드만큼 안쪽 여백.
        // WebView 자체에 여백을 주면 내용이 홈바 밑으로 들어가므로, 바깥 틀(FrameLayout)에 여백을 줌
        box = new FrameLayout(this);
        box.setBackgroundColor(Color.parseColor("#15181D"));
        box.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false); // 모든 버전에서 같은 방식(가장자리까지 그리고 여백은 직접)
            box.setOnApplyWindowInsetsListener((View v, WindowInsets insets) -> {
                android.graphics.Insets b = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets k = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(b.left, b.top, b.right, Math.max(b.bottom, k.bottom));
                return WindowInsets.CONSUMED;
            });
        } else {
            box.setFitsSystemWindows(true);
        }

        setContentView(box);
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START);

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }
    }

    /** 뒤로가기: 키보드가 떠 있으면 먼저 내리고, 게임에 처리를 물어봄. 게임이 처리하지 않으면(첫 화면) 앱을 닫음 */
    private void handleBack() {
        hideKeyboard();
        web.evaluateJavascript("(window.SGBack&&window.SGBack())?'1':'0'", value -> {
            if (!"\"1\"".equals(value)) finish();
        });
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(web.getWindowToken(), 0);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { // 안드로이드 12 이하
        handleBack();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
