# SECRET GRID 행사판(v5) — 작업 계약서 (실장)

## 제품 정의
- 중앙 화면(노트북 + 프로젝터/TV)에서 진행하는 **팀 대항전**. 1팀 = 차 1대. 한 경주 최대 10대.
- 10팀이면 A조(1~5팀)·B조(6~10팀)가 번갈아 예선 N판(기본 3판) → 상위 8팀 결승 2판. 팀 수·판 수는 설정 가능.
- '빠른 경기' 모드도 유지: 이름 2~10명 입력해 바로 한 판 (기존 한 기기 버전과 같은 사용법).
- 비밀 장치는 **트랩 / 지름길 / 방어막** 3종. 매 판 각 팀 대표가 노트북에서 몰래 고름(15초 타이머, 확인 단계).
- 최종 결과물은 단일 HTML 파일 하나(아티팩트로 게시). 외부 의존은 Google Fonts뿐(없어도 동작). 서버 없음.

## 폴더: /home/claude/game2/
| 파일 | 담당 | 내용 |
|---|---|---|
| engine.js | 개발자 | 결정적 경주 엔진 (규칙의 유일한 원본) |
| tests/engine.test.cjs, tests/balance.cjs | 개발자(QA 겸) | 연결·결정성·회귀 테스트, 승률표 |
| render.js | UI 디자이너 | 캔버스 그리기 (트랙 캐시, 차, 번호표, 장치, 효과) |
| index.html, style.css | UI 디자이너 | 모든 화면 마크업·스타일 (목업 데이터로 확인) |
| app.js | 실장 | 화면 전환·대회 진행·저장(localStorage) — 엔진과 render 연결 |
| build.cjs | 실장 | 하나의 HTML로 묶기 |

**자기 파일만 수정할 것.** 다른 사람 파일은 읽기만.

## 엔진 API (개발자가 지키고, 다른 사람이 의존)
```
SGEngine = { DT, tileOrder, shapeNames, FORK2, FORK3, VARIANTS, ATTACK, SECRET, BOLT, SHIELD,
  rng(seed), tileGeom(i,variant) -> {variant, routes:[{points[201]{x,y}, length}]},
  randomTiles(seed, prevTiles?, locked?) -> number[9],
  createRace(cfg) -> S, step(S), advanceTo(S, elapsedSec, maxSteps?) -> stepsRun,
  remixTile(S, i) -> bool   // 경주 중 수동 변형 (잠긴 조각·차가 도달한 조각은 false)
  standings(S) -> cars[] (순위순), carPos(S, car) -> {x,y,dx,dy}, at(S,p,route) -> {x,y,dx,dy},
  tileIndex(p), peekRoute(S,car,i), summary(S) }
cfg = { seed:int, tiles:number[9], locked?:bool[9], chaos:bool, battle:bool,
        racers:[{ id, name, device:{type:'trap'|'shortcut'|'shield', sector:0|1|2} | null }] }   // 최대 10
S.tiles[i] = {variant, routes, flash(sec), locked}
S.cars[k]  = {idx, id, p(0..1), slow, spin, immune, gauge(0..1), hits, landed, time|null, route{}, lane, shield(bool 남아있음)}
S.devices  = [{owner, type, sector, p, used, route, endRoute, fail, skip, victim}]   // shield는 위치 없음
S.shots = [{a,b,t,miss}], S.bolts = [{a,b,t}], S.t, S.n, S.done
S.events = [{t, k, a, b, ...}]  k: 'remix'|'shortcut'|'deadend'|'trap'(wild)|'hit'|'dodge'|'bolt'|'boltmiss'|'block'(방어막이 막음: a=방어막 주인, by='trap'|'missile')|'finish'(place)|'done'
S.recap = [ { owner(idx), type, sector, result, victim?, rankBefore?, ... } ]   // 범인 공개 카드용, 경주 종료 시 완성
```
좌표계: 캔버스 760 × 650(논리 픽셀). 조각 (col,row)의 영역은 x=65+col*210, y=65+row*180, 크기 210×180. 트랙은 y 65~605.

## 결정된 규칙
- 지름길로 점프할 때 **뛰어넘은 구간의 트랩은 발동하지 않음** (참가자 번호 순서와 무관하게).
- CHAOS 랜덤 변형은 잠긴 조각을 건드리지 않음.
- 방어막: 내게 오는 첫 트랩 또는 미사일 1회 무효 (번개는 못 막음 — 시뮬레이션으로 조정 가능). 균형 목표: 트랩·지름길(초·중·후)·방어막 7개 선택지 승률이 공평값 ±3%p (5명, 공격 ON·OFF, 8명·10명도 확인).
- 막판 20% 랜덤 사건 중단은 하지 않음 (시뮬레이션 기각).
