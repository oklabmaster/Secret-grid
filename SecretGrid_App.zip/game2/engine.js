/* SECRET GRID 행사판 — 경주 엔진 (규칙의 유일한 원본)
 * 같은 설계도(시드·트랙·참가자·장치)면 언제 어디서 계산해도 똑같은 경주.
 * 결정성: 고정 시간 간격(1/60초), 시드 난수(rng), 덧셈·곱셈·나눗셈·제곱근·dsin만 사용
 * (Math.random, Math.sin/cos/hypot 등은 경주 계산에 쓰지 않음).
 */
(function(G){
'use strict';
const DT=1/60, W=760, H=650;
// 트랙 배치: 조각 수별 격자(가로×세로). 길은 ㄹ자로 이어짐. 9개(3×3)가 기본
const LAYOUTS={9:[3,3],12:[3,4],15:[3,5],18:[3,6],20:[4,5],24:[4,6]}; // 세로로 길게: 가로 3~4칸
const layoutCache={};
function layoutOf(N){N=N|0;if(layoutCache[N])return layoutCache[N];const lc=LAYOUTS[N]||LAYOUTS[9],cols=lc[0],rows=lc[1],order=[];
 for(let r=0;r<rows;r++){const ltr=r%2===0,last=r===rows-1;for(let k=0;k<cols;k++){const col=ltr?k:cols-1-k,first=k===0,end=k===cols-1;let o;
  if(ltr){o=first&&r>0?'NE':'WE';if(end&&!last)o=first&&r>0?'NS':'WS'}else{o=first?'NW':'EW';if(end&&!last)o='ES'}order.push([col,r,o])}}
 return layoutCache[N]={N:cols*rows,cols,rows,order,W:130+cols*210,H:110+rows*180}}
const tileOrder=layoutOf(9).order;
const shapeNames=['지그재그','급커브','헤어핀','소용돌이','우회로','두 갈래','세 갈래'];
const FORK2=5,FORK3=6,VARIANTS=7;
const straightShapes=[
 [[0,.5],[.16,.5],[.28,.23],[.43,.77],[.58,.23],[.74,.77],[.86,.5],[1,.5]],
 [[0,.5],[.18,.5],[.28,.22],[.63,.22],[.73,.78],[.85,.78],[.87,.5],[1,.5]],
 [[0,.5],[.19,.5],[.19,.19],[.76,.19],[.76,.43],[.44,.43],[.44,.8],[.85,.8],[.85,.5],[1,.5]],
 [[0,.5],[.17,.5],[.24,.79],[.7,.79],[.82,.5],[.7,.2],[.4,.2],[.4,.5],[1,.5]],
 [[0,.5],[.17,.5],[.22,.18],[.78,.18],[.83,.5],[1,.5]]];
const cornerShapes=[
 [[0,.5],[.2,.5],[.3,.2],[.57,.4],[.8,.22],[.8,.72],[.5,.78],[.5,1]],
 [[0,.5],[.22,.5],[.3,.22],[.78,.22],[.78,.74],[.5,.74],[.5,1]],
 [[0,.5],[.18,.5],[.18,.2],[.78,.2],[.78,.48],[.46,.48],[.46,.73],[.5,1]],
 [[0,.5],[.2,.5],[.3,.2],[.73,.2],[.8,.55],[.6,.72],[.3,.72],[.3,.48],[.5,.48],[.5,1]],
 [[0,.5],[.2,.5],[.28,.2],[.76,.2],[.8,.76],[.5,.82],[.5,1]]];
const straightForks=[
 [[[0,.5],[.1,.5],[.2,.22],[.4,.16],[.6,.3],[.8,.18],[.9,.5],[1,.5]],
  [[0,.5],[.1,.5],[.22,.78],[.78,.78],[.9,.5],[1,.5]]],
 [[[0,.5],[.1,.5],[.22,.2],[.5,.14],[.78,.2],[.9,.5],[1,.5]],
  [[0,.5],[.1,.5],[.3,.5],[.5,.5],[.7,.5],[.9,.5],[1,.5]],
  [[0,.5],[.1,.5],[.2,.8],[.35,.75],[.5,.87],[.65,.75],[.8,.8],[.9,.5],[1,.5]]]];
const cornerForks=[
 [[[0,.5],[.12,.5],[.3,.58],[.4,.72],[.5,.86],[.5,1]],
  [[0,.5],[.12,.5],[.22,.2],[.78,.2],[.82,.66],[.5,.86],[.5,1]]],
 [[[0,.5],[.12,.5],[.22,.68],[.34,.8],[.5,.88],[.5,1]],
  [[0,.5],[.12,.5],[.3,.38],[.5,.4],[.62,.56],[.6,.72],[.5,.88],[.5,1]],
  [[0,.5],[.12,.5],[.2,.15],[.82,.14],[.88,.6],[.74,.82],[.5,.88],[.5,1]]]];

// 시드 난수 (mulberry32) — 정수 연산만 사용하므로 모든 브라우저에서 같은 수열
function rng(seed){let a=seed>>>0;return function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
// 결정적 사인 함수 (다항식 근사)
const PI=3.141592653589793,TAU=6.283185307179586,HALF=1.5707963267948966;
function dsin(x){x=x-Math.floor(x/TAU)*TAU;if(x>PI)x-=TAU;if(x>HALF)x=PI-x;else if(x<-HALF)x=-PI-x;const x2=x*x;return x*(1-x2/6*(1-x2/20*(1-x2/42*(1-x2/72*(1-x2/110)))))}
function dist(ax,ay,bx,by){const dx=ax-bx,dy=ay-by;return Math.sqrt(dx*dx+dy*dy)}

function sampleRoute(nodes){const sampled=[];
 for(let j=0;j<nodes.length-1;j++){const a=nodes[Math.max(0,j-1)],b=nodes[j],c=nodes[j+1],d=nodes[Math.min(nodes.length-1,j+2)];for(let k=0;k<30;k++){const u=k/30,u2=u*u,u3=u2*u;sampled.push({x:.5*(2*b.x+(-a.x+c.x)*u+(2*a.x-5*b.x+4*c.x-d.x)*u2+(-a.x+3*b.x-3*c.x+d.x)*u3),y:.5*(2*b.y+(-a.y+c.y)*u+(2*a.y-5*b.y+4*c.y-d.y)*u2+(-a.y+3*b.y-3*c.y+d.y)*u3)})}}sampled.push(nodes[nodes.length-1]);
 const cum=[0];for(let j=1;j<sampled.length;j++)cum.push(cum[j-1]+dist(sampled[j].x,sampled[j].y,sampled[j-1].x,sampled[j-1].y));const length=cum[cum.length-1],pts=[];let index=1;
 for(let j=0;j<=200;j++){const distance=j*length/200;while(index<cum.length-1&&cum[index]<distance)index++;const a=sampled[index-1],b=sampled[index],f=(distance-cum[index-1])/(cum[index]-cum[index-1]||1);pts.push({x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f})}
 return{points:pts,length}}
const geomCache={};
function tileGeom(i,variant,N){N=N||9;const key=N+':'+i+':'+variant;if(geomCache[key])return geomCache[key];const [col,row,o]=layoutOf(N).order[i],straight=o==='WE'||o==='EW';
 const shapes=variant>=FORK2?(straight?straightForks:cornerForks)[variant-FORK2]:[(straight?straightShapes:cornerShapes)[variant]];
 const routes=shapes.map(shape=>sampleRoute(shape.map(([x,y])=>{if(o==='EW'||o==='ES')x=1-x;else if(o==='NW'){const t=x;x=1-y;y=t}else if(o==='NE'){const t=x;x=y;y=t}return{x:65+col*210+x*210,y:65+row*180+y*180}})));
 return geomCache[key]={variant,routes}}
function randomVariant(R,old){if(old<0)return Math.floor(R()*VARIANTS);const v=Math.floor(R()*(VARIANTS-1));return v>=old?v+1:v}
// 방장이 '트랙 섞기'를 누를 때 쓰는 함수 (갈래길 최소 2개 보장)
function randomTiles(seed,prev,locked,N){N=prev&&!N?prev.length:(LAYOUTS[N]?N:9);if(prev&&prev.length!==N)prev=null;const R=rng(seed),t=[];for(let i=0;i<N;i++)t.push(prev&&locked&&locked[i]?prev[i]:randomVariant(R,prev?prev[i]:-1));let forks=t.filter(v=>v>=FORK2).length;const need=Math.max(2,Math.round(N*2/9));const pool=Array.from({length:N-2},(_,k)=>k+1).filter(i=>!(locked&&locked[i])&&t[i]<FORK2);while(forks<need&&pool.length){const i=pool.splice(Math.floor(R()*pool.length),1)[0];t[i]=R()<.5?FORK2:FORK3;forks++}return t}

// 차선: 노면 폭 25px, 차 폭 10px → 중심 오프셋은 ±7.5 이내여야 노면 안. 10대까지 한 줄로 고르게, 그 이상은 10줄 반복.
function laneFor(i,n){if(n<=10){const s=Math.min(1.9,14/Math.max(1,n-1));return(i-(n-1)/2)*s}return((i%10)-4.5)*1.55}
// 경주 기본값: speed(초당 픽셀), slowFactor(감속 중 속도 비율), remixEvery(랜덤 변형 간격 초), wobble(속도 흔들림)
const RACE={speed:115,slowFactor:.2,remixEvery:5,wobble:.12};
const ATTACK={charge:7,catchup:.8,range:90,reach:.05,stun:1.4,dodge:.2,immune:3,flight:.3};
// 비밀 장치 균형: 일찍 설치할수록 효과가 크고, 발동해 봐야 결과를 알 수 있음 (tests/balance.cjs로 조정한 값)
// skip: 지름길이 건너뛰는 거리(초·중·후반), slow: 트랩에 걸린 차 감속 시간(초, 속도 20%)
// steal: 트랩이 걸리면 설치한 차가 얻는 가속 시간(초, 속도×stealSpeed) — 방어막에 막히면 없음
// deadEnd: 지름길이 막다른 길일 확률·멈추는 시간, wild: 트랩이 엉뚱한 차를 잡을 확률
// crowd: 6대 이상일 때 지름길 거리 감소율(1대당, 초·중·후반) — 차가 많을수록 점프로 추월하는 대수가 늘어나는 것 보정
// few: 4대 이하일 때 트랩 감속·가속 시간 감소율(1대당) — 상대가 적으면 트랩 한 번의 가치가 커지는 것 보정
// trapAt/cutAt: 초·중·후반 설치 위치(진행률, ±0.03 무작위)
// battle: 공격(BATTLE) ON일 때만 덮어쓰는 수치(없는 항목은 위 값). 미사일 때문에 장치 가치가 달라져 따로 맞춤
const SECRET={skip:[.095,.046,.032],slow:[8.5,6,3.4],steal:[4,2,.5],stealSpeed:1.3,deadEnd:.25,deadStun:1.4,wild:.25,crowd:[0,0,.06],few:.15,trapAt:[.25,.5,.75],cutAt:[.25,.5,.75],
 battle:{skip:[.065,.036,.032],steal:[5,3,.5]}};
function sv(S,k){const b=S.cfg.battle&&SECRET.battle;return b&&b[k]!==undefined?b[k]:SECRET[k]}
// 꼴찌의 번개: 일정 간격으로 꼴찌가 선두에게 번개를 떨어뜨림
// 맵 트랩(진행자가 지도에 직접 까는 공용 장애물): 지나가는 차가 구간별 확률(chance: 초반·중반·후반)로 걸려 slow초 감속
const HAZARD={slow:1.2,chance:[.7,.5,.35]};
function hazardSector(p){return p<1/3?0:p<2/3?1:2}
const BOLT={on:true,start:8,every:9,stun:1.5,immune:2,pierce:false};
// 방어막: 막는 공격 종류와 횟수. 막으면 잠깐 무적(immune초). 시뮬레이션 결과 트랩만 막는 것이 공평(미사일까지 막으면 미사일에 먼저 소모돼 승률 16%대)
const SHIELD={trap:true,missile:false,bolt:false,charges:1,immune:1};

/* cfg = {seed, tiles:[9], locked?:[9], chaos, battle, racers:[{id,name,device:{type,sector}|null}]} */
function createRace(cfg){const R=rng(cfg.seed|0),n=cfg.racers.length,lk=cfg.locked||[];
 const S={cfg,R,t:0,steps:0,n,tiles:cfg.tiles.map((v,i)=>({variant:v,flash:-1,routes:tileGeom(i,v,cfg.tiles.length).routes,locked:!!lk[i]})),cars:[],devices:[],shots:[],events:[],finished:[],nextRemix:RACE.remixEvery,remixCount:0,done:false,wob:(cfg.seed|0)%1000,charge:ATTACK.charge+Math.max(0,n-8)*.1,recap:[],_rec:[]};
 S.cars=cfg.racers.map((r,i)=>({idx:i,id:r.id,p:0,slow:0,spin:0,immune:0,gauge:R()*.4,hits:0,landed:0,time:null,route:{},lane:laneFor(i,n),shield:false,shieldLeft:0,boost:0}));
 cfg.racers.forEach((r,i)=>{const d=r.device;if(!d)return;
  if(d.type==='trap'||d.type==='shortcut'){const s=Math.max(0,Math.min(2,d.sector|0));S.devices.push({owner:i,type:d.type,sector:s,p:sv(S,d.type==='trap'?'trapAt':'cutAt')[s]+(R()-.5)*.06,used:false,route:0,endRoute:0,fail:false,skip:0,victim:null,blocked:false});S._rec[i]={owner:i,type:d.type,sector:s,result:'unused'}}
  else if(d.type==='shield'){const c=S.cars[i];c.shieldLeft=SHIELD.charges;c.shield=c.shieldLeft>0;S._rec[i]={owner:i,type:'shield',sector:null,result:'unused'}}});
 S.nextBolt=BOLT.start;S.bolts=[];S.hazards=(Array.isArray(cfg.hazards)?cfg.hazards:[]).map(p=>+p).filter(p=>p>0&&p<1).sort((a,b)=>a-b).map(p=>({p,hits:0,miss:0}));
 return S}
function tileIndex(p,N){return Math.floor(Math.max(0,Math.min(.999999,p))*(N||9))}
function routeOf(S,c,i){const n=S.tiles[i].routes.length;if(c.route[i]===undefined||c.route[i]>=n)c.route[i]=Math.floor(S.R()*n);return c.route[i]}
function peekRoute(S,c,i){const r=c.route[i];return r===undefined||r>=S.tiles[i].routes.length?0:r}
function at(S,p,r){const f=Math.max(0,Math.min(.999999,p))*S.tiles.length,i=Math.floor(f),routes=S.tiles[i].routes,pts=(routes[Math.min(r||0,routes.length-1)]).points,local=(f-i)*200,j=Math.floor(local),a=pts[j],b=pts[Math.min(200,j+1)],u=local-j;return{x:a.x+(b.x-a.x)*u,y:a.y+(b.y-a.y)*u,dx:b.x-a.x,dy:b.y-a.y}}
function carPos(S,c){return at(S,c.p,peekRoute(S,c,tileIndex(c.p,S.tiles.length)))}
function standings(S){return S.cars.slice().sort((a,b)=>a.time!==null&&b.time!==null?a.time-b.time:a.time!==null?-1:b.time!==null?1:b.p-a.p)}
function rankOf(S,c){return standings(S).indexOf(c)+1}
function ev(S,e){e.t=S.t;S.events.push(e)}

// 방어막 1회 소모. 막았으면 true
function useShield(S,c,kind,attacker){if(!SHIELD[kind]||c.shieldLeft<=0)return false;c.shieldLeft--;c.shield=c.shieldLeft>0;c.immune=Math.max(c.immune,S.t+SHIELD.immune);
 const r=S._rec[c.idx];if(r&&r.type==='shield'){if(r.result!=='blocked'){r.result='blocked';r.by=kind;r.attacker=attacker;r.blocks=[]}r.blocks.push({by:kind,attacker})}
 ev(S,{k:'block',a:c.idx,b:attacker,by:kind});return true}

function doRemix(S,i,manual){const t=S.tiles[i];t.variant=randomVariant(S.R,t.variant);t.routes=tileGeom(i,t.variant,S.tiles.length).routes;t.flash=S.t+1;for(const c of S.cars)delete c.route[i];S.remixCount++;ev(S,manual?{k:'remix',tile:i,v:t.variant,manual:true}:{k:'remix',tile:i,v:t.variant})}
function remix(S){const racing=S.cars.filter(c=>c.time===null);let lead=-1;for(const c of racing)lead=Math.max(lead,c.p*S.tiles.length);
 const eligible=[];for(let i=0;i<S.tiles.length;i++)if(i>lead+.08&&!S.tiles[i].locked)eligible.push(i);if(!eligible.length)return;
 doRemix(S,eligible[Math.floor(S.R()*eligible.length)],false)}
// 경주 중 수동 변형 (진행자 버튼). 잠긴 조각, 또는 달리는 차가 이미 도달(직전 포함)한 조각은 거부
function remixTile(S,i){if(S.done||!(i>=0&&i<S.tiles.length)||(i|0)!==i||S.tiles[i].locked)return false;for(const c of S.cars)if(c.time===null&&c.p*S.tiles.length>=i-.08)return false;doRemix(S,i,true);return true}

function attacks(S){const racing=standings(S).filter(c=>c.time===null),m=racing.length,pos=new Map();for(const c of racing)pos.set(c,carPos(S,c));
 racing.forEach((c,place)=>{const rate=(1/S.charge)*(1+ATTACK.catchup*place/Math.max(1,m-1));c.gauge=Math.min(1,c.gauge+rate*DT);
  if(c.gauge<1||c.spin>S.t)return;const me=pos.get(c);let target=null,best=Infinity;
  for(const o of racing){if(o===c||o.p<=c.p||o.p-c.p>ATTACK.reach||o.immune>S.t)continue;const op=pos.get(o),d=dist(op.x,op.y,me.x,me.y);if(d<ATTACK.range&&d<best){best=d;target=o}}
  if(!target)return;c.gauge=0;const miss=S.R()<ATTACK.dodge,shot={a:c.idx,b:target.idx,t:S.t,miss};S.shots.push(shot);if(S.shots.length>40)S.shots.shift();
  if(miss){target.immune=S.t+1;ev(S,{k:'dodge',a:c.idx,b:target.idx})}
  else if(useShield(S,target,'missile',c.idx)){shot.blocked=true}
  else{c.landed++;target.hits++;target.slow=Math.max(target.slow,S.t+ATTACK.flight+ATTACK.stun);target.spin=S.t+ATTACK.flight+ATTACK.stun;target.immune=S.t+ATTACK.immune;ev(S,{k:'hit',a:c.idx,b:target.idx})}})}

function bolt(S){if(!BOLT.on||S.cfg.bolt===false||S.t<S.nextBolt)return;S.nextBolt=S.t+BOLT.every;const racing=standings(S).filter(c=>c.time===null);if(racing.length<2)return;
 const last=racing[racing.length-1],lead=racing[0];if((BOLT.pierce?lead.boltImmune||0:lead.immune)>S.t){ev(S,{k:'boltmiss',a:last.idx,b:lead.idx});return}
 if(useShield(S,lead,'bolt',last.idx)){S.bolts.push({a:last.idx,b:lead.idx,t:S.t,blocked:true});if(S.bolts.length>10)S.bolts.shift();return}
 lead.slow=Math.max(lead.slow,S.t+BOLT.stun);lead.spin=S.t+BOLT.stun;lead.immune=Math.max(lead.immune,S.t+BOLT.immune);lead.boltImmune=S.t+BOLT.immune;S.bolts.push({a:last.idx,b:lead.idx,t:S.t});if(S.bolts.length>10)S.bolts.shift();ev(S,{k:'bolt',a:last.idx,b:lead.idx})}

// 이번 스텝에 차 c가 (old, c.p] 구간에서 지난 장치를 p 오름차순으로 처리.
// 내 지름길로 점프하면 (점프 지점, 착지 지점] 구간의 장치는 모두 건너뜀(이번 스텝 남은 것 포함, 다음 스텝은 착지 지점에서 시작).
function crossDevices(S,c,old,t){let list=null;
 for(const d of S.devices){if(d.used||!(old<d.p&&c.p>=d.p))continue;if(d.type==='shortcut'?d.owner!==c.idx:d.owner===c.idx)continue;(list||(list=[])).push(d)}
 if(!list)return;
 if(list.length>1)list.sort((a,b)=>a.p-b.p||a.owner-b.owner||(a.type<b.type?-1:a.type>b.type?1:0));
 for(const d of list){d.used=true;d.route=routeOf(S,c,tileIndex(d.p,S.tiles.length));const rec=S._rec[d.owner];
  if(d.type==='shortcut'){rec.rankBefore=rankOf(S,c);
   if(S.R()<sv(S,'deadEnd')){d.fail=true;c.slow=Math.max(c.slow,t+sv(S,'deadStun'));rec.result='deadend';ev(S,{k:'deadend',a:c.idx})}
   else{d.skip=sv(S,'skip')[d.sector]*Math.max(.5,1-sv(S,'crowd')[d.sector]*Math.max(0,S.n-5));c.p+=d.skip;if(c.p<1)d.endRoute=routeOf(S,c,tileIndex(c.p,S.tiles.length));rec.result='jump';rec.rankAfter=rankOf(S,c);ev(S,{k:'shortcut',a:c.idx});break}}
  else{let victim=c,wild=false;
   if(S.R()<sv(S,'wild')){const pool=S.cars.filter(o=>o.time===null&&o.idx!==d.owner);if(pool.length){victim=pool[Math.floor(S.R()*pool.length)];wild=victim!==c}}
   d.victim=victim.idx;rec.victim=victim.idx;rec.wild=wild;rec.rankBefore=rankOf(S,victim);
   if(useShield(S,victim,'trap',d.owner)){d.blocked=true;rec.result='blocked'}
   else{const fw=Math.max(.3,1-sv(S,'few')*Math.max(0,5-S.n));victim.slow=Math.max(victim.slow,t+sv(S,'slow')[d.sector]*fw);const st=sv(S,'steal')[d.sector]*fw;if(st){const o=S.cars[d.owner];o.boost=Math.max(o.boost,t+st)}rec.result=wild?'wild':'hit';ev(S,{k:'trap',a:d.owner,b:victim.idx,wild})}}}}

function finishRecap(S){const st=standings(S),rk=new Map();st.forEach((c,i)=>rk.set(c.idx,i+1));
 S.recap=[];for(let i=0;i<S.n;i++){const r=S._rec[i];if(!r)continue;const o=Object.assign({},r);if(o.blocks)o.blocks=o.blocks.map(b=>Object.assign({},b));
  o.ownerRank=rk.get(i);if(o.type==='trap'&&o.victim!=null)o.victimRank=rk.get(o.victim);S.recap.push(o)}}

function step(S){if(S.done)return;S.t+=DT;S.steps++;const t=S.t;
 if(S.cfg.chaos&&t>=S.nextRemix){S.nextRemix=t+RACE.remixEvery;remix(S)}
 for(const c of S.cars){if(c.time!==null)continue;const old=c.p,i=tileIndex(c.p,S.tiles.length),r=routeOf(S,c,i);
  // 조각 수가 늘어도 경주 시간은 비슷하게: 조각당 진행률 1/N, 화면 속도 speed×N/9 → 공식의 9는 그대로
  let speed=(RACE.speed/(S.tiles[i].routes[r].length*9))*(1+RACE.wobble*dsin(t*1.4+c.idx*2.4+S.wob));if(c.slow>t)speed*=RACE.slowFactor;else if(c.boost>t)speed*=sv(S,'stealSpeed');c.p+=speed*DT;
  const moved=c.p;crossDevices(S,c,old,t);
  // 맵 트랩: 이번 걸음에 지나간 것만 (지름길로 뛰어넘은 구간은 제외)
  if(S.hazards.length)for(let h=0;h<S.hazards.length;h++){const z=S.hazards[h];if(old<z.p&&moved>=z.p){const ch=HAZARD.chance[hazardSector(z.p)];if(S.R()<ch){z.hits++;c.slow=Math.max(c.slow,t+HAZARD.slow);ev(S,{k:'hazard',a:c.idx,h})}else{z.miss++;ev(S,{k:'hazardmiss',a:c.idx,h})}}}
  if(c.p>=1){c.time=t-DT+(1-old)/Math.max(c.p-old,.00001)*DT;c.p=1;S.finished.push(c);ev(S,{k:'finish',a:c.idx,place:S.finished.length})}
  else routeOf(S,c,tileIndex(c.p,S.tiles.length))}
 if(S.cfg.battle)attacks(S);
 bolt(S);
 if(S.finished.length===S.n||t>600){S.done=true;finishRecap(S);ev(S,{k:'done'})}}
// 경주 시작 후 elapsed초까지 계산 (늦게 들어온 사람도 같은 상태로 따라잡음)
function advanceTo(S,elapsed,maxSteps){let k=0;const lim=maxSteps||Infinity;while(!S.done&&(S.steps+1)*DT<=elapsed&&k<lim){step(S);k++}return k}
function summary(S){return standings(S).map(c=>({idx:c.idx,id:c.id,time:c.time===null?null:Math.round(c.time*1000)/1000,p:Math.round(c.p*1e6)/1e6,hits:c.hits,landed:c.landed}))}

const api={hazardSector,DT,W,H,tileOrder,layoutOf,LAYOUTS,shapeNames,FORK2,FORK3,VARIANTS,RACE,ATTACK,SECRET,BOLT,SHIELD,HAZARD,rng,dsin,tileGeom,randomTiles,laneFor,createRace,step,advanceTo,remixTile,standings,carPos,at,tileIndex,peekRoute,summary};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else G.SGEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this);
