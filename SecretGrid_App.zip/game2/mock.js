/* 목업 데이터 — 디자인 확인용. index.html?mock=<화면> 일 때만 동작 (build.cjs가 묶을 때 빠짐)
 * 화면: start | lobby | secret | secret2 | secret3 | race | race-pre | result | board | final-intro | final
 * 추가: &n=10 (팀 수), &t=22 (레이스 시점 초), &play=1 (실시간 재생), &q=1 (DPR 1)
 * 실장 참고: 템플릿 복제·번호판 칠하기·타워 갱신 방법의 예시이기도 함. */
(function(){
'use strict';
const qs=new URLSearchParams(location.search),screen=qs.get('mock');if(!screen)return;
const $=id=>document.getElementById(id),R=window.SGRender,E=window.SGEngine;
const N=Math.max(2,Math.min(10,+(qs.get('n')||10)));
const TEAMS=['치아요정','크라운킹','브릿지','임플란트','지르코니아','인레이','라미네이트','덴처','교정왕','스마일'];
const name=i=>`${i+1}팀 ${TEAMS[i]}`;
const tpl=id=>$(id).content.firstElementChild.cloneNode(true);
const plate=(el,i)=>R.paintPlate(el,i);
function show(id,broadcast){document.querySelectorAll('.screen').forEach(s=>s.hidden=s.id!==id);document.body.classList.toggle('is-broadcast',!!broadcast)}

// 가짜 대회 상태 + 실제 엔진 경주
const tiles=E.randomTiles(4242);
const racers=Array.from({length:N},(_,i)=>({id:'t'+(i+1),name:name(i),device:[{type:'trap',sector:0},{type:'shortcut',sector:1},{type:'shield',sector:0},{type:'trap',sector:1},{type:'shortcut',sector:0}][i%5]}));
function race(){return E.createRace({seed:777,tiles,chaos:true,battle:true,racers})}

function fillInputs(box,n){box.replaceChildren();for(let i=0;i<n;i++){const r=tpl('tpl-team-input');plate(r.querySelector('.plate'),i);const inp=r.querySelector('input');inp.value=TEAMS[i];inp.setAttribute('aria-label',`${i+1}팀 이름`);box.append(r)}}
function entries(box,list){box.replaceChildren();for(const i of list){const e=tpl('tpl-entry');plate(e.querySelector('.plate'),i);e.querySelector('.entry-name').textContent=TEAMS[i];box.append(e)}}

function tower(S){const list=$('race-tower'),order=E.standings(S),battle=S.cfg.battle;$('race-tower').parentElement.classList.toggle('no-gauge',!battle);
 if(list.children.length!==order.length){list.replaceChildren();order.forEach(()=>list.append(tpl('tpl-tower-row')))}
 order.forEach((c,i)=>{const row=list.children[i];row.querySelector('.tw-pos').textContent=i+1;plate(row.querySelector('.plate'),c.idx);row.querySelector('.tw-name').textContent=TEAMS[c.idx];
  const slow=c.time===null&&c.slow>S.t,hit=c.time===null&&c.spin>S.t;row.className='tw-row'+(i===0?' is-lead':'')+(slow?' is-slow':'')+(hit?' is-hit':'')+(c.time!==null?' is-done':'');
  row.querySelector('.tw-stat').textContent=c.time!==null?c.time.toFixed(2):hit?'피격':slow?'감속':Math.floor(c.p*100)+'%';
  const g=row.querySelector('.gauge');g.style.setProperty('--g',c.time===null?c.gauge.toFixed(2):0);g.classList.toggle('is-full',c.time===null&&c.gauge>=1)})}
function banner(text,kind){const b=$('race-banner');$('race-banner-text').textContent=text;b.dataset.kind=kind;b.classList.add('is-show')}

function lobby(){show('screen-lobby');const Rr=R.createRenderer($('lobby-canvas'));Rr.setTrack(tiles,{selectedTile:4});
 const view={selectedTile:4,mode:'preview'};entries($('lobby-teams'),[0,1,2,3,4]);
 $('lobby-tile-info').textContent=`5번 조각 · ${E.shapeNames[tiles[4]]}`;
 const draw=()=>Rr.drawFrame(null,view);draw();addEventListener('resize',()=>{Rr.resize();draw()});
 $('lobby-canvas').addEventListener('click',e=>{const i=Rr.pick(e.clientX,e.clientY);if(i>=0){view.selectedTile=i;$('lobby-tile-info').textContent=`${i+1}번 조각 · ${E.shapeNames[tiles[i]]}`;draw()}});
 return Rr}

function raceScreen(pre){show('screen-race',true);const S=race(),Rr=R.createRenderer($('race-canvas'));if(qs.get('q'))Rr.setQuality(1);
 $('race-stage').textContent=N>5?'결승 1/2판':'예선 A조 2/3판';
 const view={mode:'race',selectedTile:-1,showBadges:true};
 if(pre){$('race-live').hidden=true;view.mode='preview';view.sectors=false;Rr.drawFrame(S,view);tower(S);$('race-timer').textContent='0.0';return}
 $('race-start').hidden=true;
 if(qs.get('play')){const frames=[];window.__frames=frames;let t0=performance.now(),lastUi=0,lastEv=0;
  (function tick(now){const t=(now-t0)/1000;E.advanceTo(S,t,30);const a=performance.now();Rr.drawFrame(S,view);
   if(t-lastUi>.1){tower(S);$('race-timer').textContent=S.t.toFixed(1);lastUi=t}
   while(lastEv<S.events.length){const e=S.events[lastEv++];if(e.k==='trap')banner(`${e.a+1}팀 트랩 → ${e.b+1}팀 감속`,'trap');if(e.k==='bolt')banner(`꼴찌 ${e.a+1}팀의 번개! 선두 ${e.b+1}팀 정지`,'bolt')}
   frames.push(performance.now()-a);if(!S.done&&frames.length<100000)requestAnimationFrame(tick);else window.__done=true})(performance.now());return}
 const T=+(qs.get('t')||22);E.advanceTo(S,T);Rr.drawFrame(S,view);tower(S);$('race-timer').textContent=S.t.toFixed(1);
 banner('3팀 트랩 → 7팀이 6초 동안 느려집니다','trap');window.__S=S}

function secret(step){lobby();const d=$('dlg-secret');d.showModal();$('secret-progress').textContent=`3 / ${N}팀`;plate($('secret-plate'),2);$('secret-team').textContent=name(2);
 $('secret-handoff').hidden=step!==1;$('secret-choose').hidden=step!==2;$('secret-confirm').hidden=step!==3;
 if(step===2){$('secret-timer').textContent='4';const ring=document.querySelector('.timer-ring');ring.style.setProperty('--p',4/15);ring.classList.add('is-low')}}

function result(){show('screen-result');const S=race();E.advanceTo(S,1e9);$('result-stage').textContent='예선 A조 2/3판 결과';const pts=[10,7,5,3,1,0,0,0,0,0];
 E.standings(S).forEach((c,i)=>{const r=tpl('tpl-result-row');r.querySelector('.rs-pos').textContent=i+1;plate(r.querySelector('.plate'),c.idx);r.querySelector('.rs-name').textContent=TEAMS[c.idx];r.querySelector('.rs-time').textContent=c.time.toFixed(2)+'초';r.querySelector('.rs-pts').textContent='+'+(pts[i]||0);$('result-rank').append(r)});
 const recap=[{o:2,type:'trap',what:'트랩 · 초반',res:'7팀이 걸려 8.5초 감속',swing:'1위 → 4위',r:'bad'},{o:1,type:'shortcut',what:'지름길 · 중반',res:'5% 점프 성공',swing:'5위 → 2위',r:'good'},{o:4,type:'shortcut',what:'지름길 · 초반',res:'막다른 길! 1.4초 정지',swing:'3위 → 6위',r:'bad'},{o:3,type:'shield',what:'방어막',res:'9팀 미사일을 막음',swing:'',r:'good'},{o:0,type:'trap',what:'트랩 · 중반',res:'엉뚱하게 2팀이 걸림',swing:'2위 → 3위',r:'bad'},{o:8,type:'shield',what:'방어막',res:'아무 공격도 받지 않음',swing:'',r:'none'}];
 for(const k of recap.slice(0,Math.min(N,6))){const c=tpl('tpl-recap');c.dataset.type=k.type;c.dataset.result=k.r;c.querySelector('.ico').classList.add('ico-'+k.type);plate(c.querySelector('.plate'),k.o);c.querySelector('.rc-name').textContent=TEAMS[k.o];c.querySelector('.rc-what').textContent=k.what;c.querySelector('.rc-result').textContent=k.res;c.querySelector('.rc-swing').textContent=k.swing;$('result-recap').append(c)}}

function board(){show('screen-board');const heats=3;
 [['A조',2],['B조',1]].forEach(([g,d])=>{const p=tpl('tpl-group-progress');p.querySelector('.gp-name').textContent=g;for(let i=0;i<heats;i++){const dot=document.createElement('i');if(i<d)dot.className='is-done';else if(i===d)dot.className='is-next';p.querySelector('.gp-dots').append(dot)}p.querySelector('.gp-text').textContent=`${d}/${heats}판`;$('board-progress').append(p)});
 const head=$('board-head');head.innerHTML='<th scope="col">팀</th>'+[1,2,3].map(i=>`<th scope="col">${i}판</th>`).join('')+'<th scope="col">합계</th>';
 const ranks=[[1,3,0],[2,1,0],[4,2,0],[3,5,0],[5,4,0],[1,2,0],[3,1,0],[2,4,0],[5,3,0],[4,5,0]].slice(0,N),P=[0,10,7,5,3,1];
 const rows=ranks.map((r,i)=>({i,r,tot:r.reduce((a,x)=>a+(P[x]||0),0)})).sort((a,b)=>b.tot-a.tot);
 rows.forEach((row,k)=>{const tr=tpl('tpl-board-row');plate(tr.querySelector('.plate'),row.i);tr.querySelector('.bt-name').textContent=TEAMS[row.i];
  if(row.i===2){const ic=document.createElement('i');ic.className='ico ico-missile';ic.title='저격수상 후보';tr.querySelector('.bt-awards').append(ic)}
  const total=tr.querySelector('.cell-total');row.r.forEach(x=>{const td=document.createElement('td');td.className='cell-race'+(x===1?' is-win':'');td.innerHTML=x?`${x}<small>위</small>`:'—';tr.insertBefore(td,total)});total.textContent=row.tot;
  if(k<8)tr.classList.add('is-final');else tr.classList.add('is-out');if(k===7&&N>8)tr.classList.add('cut-line');$('board-body').append(tr)})}

function final(intro){show('screen-final',true);const s=$('screen-final');s.dataset.phase=intro?'intro':'award';
 entries($('final-teams'),[0,5,1,6,2,7,3,4].slice(0,Math.min(8,N)));
 [[1,0,'38점'],[2,5,'31점'],[3,6,'29점']].forEach(([p,i,sc])=>{const el=$('podium-'+p);plate(el.querySelector('.plate'),i);el.querySelector('.pd-name').textContent=TEAMS[i];el.querySelector('.pd-score').textContent=sc});
 [['award-sniper',2,'미사일 명중 7회'],['award-trap',6,'트랩으로 순위 9계단 흔듦'],['award-unlucky',8,'번개 4번 맞음']].forEach(([id,i,why])=>{const el=$(id);plate(el.querySelector('.plate'),i);el.querySelector('.aw-name').textContent=TEAMS[i];el.querySelector('.aw-why').textContent=why})}

function start(){show('screen-start');fillInputs($('tour-teams'),N);fillInputs($('quick-names'),4);$('tour-count').textContent=N;$('start-resume').hidden=false;$('start-resume-info').textContent='저장된 대회: 예선 A조 2/3판까지 진행'}

({start,lobby,secret:()=>secret(1),secret2:()=>secret(2),secret3:()=>secret(3),race:()=>raceScreen(false),'race-pre':()=>raceScreen(true),result,board,'final-intro':()=>final(true),final:()=>final(false)}[screen]||start)();
})();
